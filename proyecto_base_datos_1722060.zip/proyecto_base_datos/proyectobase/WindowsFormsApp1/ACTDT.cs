﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;
using System.Data;



namespace WindowsFormsApp1
{
    public class ACTDT: ConDB
    {
        public static DataTable Coord(string C, string P, string T)
        {
            DataTable DT = new DataTable();
            ConDB conexion = new ConDB();

            DT = conexion.listcord();

            return DT;
        }

    }
}
