﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    class CarDB: ConDB
    {

        public CarDB() {

         

        }

       
        DataTable RTCA = new DataTable();

     

       


        public DataTable listcarr()
        {
            
           
            RTCA = CA_listcarr();
            return RTCA;
        }

        public void carnew( string name, string des, string clave, int C_S,int creditos, int ID_Co)
        {
CA_carnew(name,des,clave,C_S,creditos,ID_Co);
         
        }


        public DataTable selcar(int id)
        {
          
            
            RTCA=CA_selcar(id);
            return RTCA;
        }


        public DataTable regisC(int id)
        {



           
            RTCA = CA_regis(id);
            return RTCA;
        }


        public void modyF(int id, string name, string des, string clave, int C_S, int creditos, int ID_Co)
        {
           
            CA_modyF(id, name, des, clave, C_S, creditos, ID_Co);

        }


        public DataTable CBcar_A(int id) {



           
            RTCA = CA_CBcar_A(id);

            return RTCA;

        }

        public DataTable listfalt()
        {


            RTCA = CA_listcarrfalt();
            return RTCA;
        }

    }
}

