﻿namespace WindowsFormsApp1
{
    partial class CarED
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.sem_N = new System.Windows.Forms.NumericUpDown();
            this.button1 = new System.Windows.Forms.Button();
            this.Cord_CB = new System.Windows.Forms.ComboBox();
            this.Cancelar = new System.Windows.Forms.Button();
            this.editar = new System.Windows.Forms.Button();
            this.agregar = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.cl_TB = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Nam_TB = new System.Windows.Forms.TextBox();
            this.CT_S = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.sem_N)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CT_S)).BeginInit();
            this.SuspendLayout();
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(20, 211);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(709, 74);
            this.textBox2.TabIndex = 61;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(17, 179);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(246, 17);
            this.label2.TabIndex = 60;
            this.label2.Text = "Descripcion  (150 caracteres maximo)";
            // 
            // sem_N
            // 
            this.sem_N.Location = new System.Drawing.Point(196, 136);
            this.sem_N.Name = "sem_N";
            this.sem_N.Size = new System.Drawing.Size(120, 22);
            this.sem_N.TabIndex = 59;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(625, 43);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(104, 32);
            this.button1.TabIndex = 58;
            this.button1.Text = "crear";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Cord_CB
            // 
            this.Cord_CB.FormattingEnabled = true;
            this.Cord_CB.Location = new System.Drawing.Point(196, 48);
            this.Cord_CB.Name = "Cord_CB";
            this.Cord_CB.Size = new System.Drawing.Size(417, 24);
            this.Cord_CB.TabIndex = 57;
            this.Cord_CB.SelectedIndexChanged += new System.EventHandler(this.Cord_CB_SelectedIndexChanged);
            // 
            // Cancelar
            // 
            this.Cancelar.Location = new System.Drawing.Point(625, 309);
            this.Cancelar.Name = "Cancelar";
            this.Cancelar.Size = new System.Drawing.Size(104, 32);
            this.Cancelar.TabIndex = 56;
            this.Cancelar.Text = "Cancelar";
            this.Cancelar.UseVisualStyleBackColor = true;
            this.Cancelar.Click += new System.EventHandler(this.Cancelar_Click);
            // 
            // editar
            // 
            this.editar.Location = new System.Drawing.Point(159, 309);
            this.editar.Name = "editar";
            this.editar.Size = new System.Drawing.Size(104, 32);
            this.editar.TabIndex = 55;
            this.editar.Text = "Editar";
            this.editar.UseVisualStyleBackColor = true;
            this.editar.Click += new System.EventHandler(this.editar_Click);
            // 
            // agregar
            // 
            this.agregar.Location = new System.Drawing.Point(20, 309);
            this.agregar.Name = "agregar";
            this.agregar.Size = new System.Drawing.Size(104, 32);
            this.agregar.TabIndex = 54;
            this.agregar.Text = "Agregar";
            this.agregar.UseVisualStyleBackColor = true;
            this.agregar.Click += new System.EventHandler(this.agregar_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(17, 138);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(153, 17);
            this.label7.TabIndex = 53;
            this.label7.Text = "Cantidad de semestres";
            // 
            // cl_TB
            // 
            this.cl_TB.Location = new System.Drawing.Point(196, 88);
            this.cl_TB.Name = "cl_TB";
            this.cl_TB.Size = new System.Drawing.Size(533, 22);
            this.cl_TB.TabIndex = 52;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(17, 91);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(43, 17);
            this.label5.TabIndex = 51;
            this.label5.Text = "Clave";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(17, 51);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(86, 17);
            this.label3.TabIndex = 50;
            this.label3.Text = "Coordinador";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(128, 17);
            this.label1.TabIndex = 49;
            this.label1.Text = "Nombre de carrera";
            // 
            // Nam_TB
            // 
            this.Nam_TB.Location = new System.Drawing.Point(196, 12);
            this.Nam_TB.Name = "Nam_TB";
            this.Nam_TB.Size = new System.Drawing.Size(533, 22);
            this.Nam_TB.TabIndex = 48;
            // 
            // CT_S
            // 
            this.CT_S.Location = new System.Drawing.Point(444, 136);
            this.CT_S.Name = "CT_S";
            this.CT_S.Size = new System.Drawing.Size(120, 22);
            this.CT_S.TabIndex = 63;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(334, 138);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(104, 17);
            this.label4.TabIndex = 62;
            this.label4.Text = "creditos totales";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(281, 317);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(160, 17);
            this.label6.TabIndex = 64;
            this.label6.Text = "seleccionar coordinador";
            // 
            // CarED
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(742, 359);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.CT_S);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.sem_N);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Cord_CB);
            this.Controls.Add(this.Cancelar);
            this.Controls.Add(this.editar);
            this.Controls.Add(this.agregar);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.cl_TB);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Nam_TB);
            this.Name = "CarED";
            this.Text = "CarED";
            this.Activated += new System.EventHandler(this.CarED_Activated);
            this.Load += new System.EventHandler(this.CarED_Load);
            ((System.ComponentModel.ISupportInitialize)(this.sem_N)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CT_S)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown sem_N;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox Cord_CB;
        private System.Windows.Forms.Button Cancelar;
        private System.Windows.Forms.Button editar;
        private System.Windows.Forms.Button agregar;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox cl_TB;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox Nam_TB;
        private System.Windows.Forms.NumericUpDown CT_S;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
    }
}