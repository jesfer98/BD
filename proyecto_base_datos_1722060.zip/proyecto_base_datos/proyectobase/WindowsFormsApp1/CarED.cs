﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class CarED : Form
    {
        private DataTable DT = new DataTable();
        private DataTable DT2 = new DataTable();
        public static string SetValueForText1 = "";
        public static Boolean Act = false;
        public static Boolean edt= false;


        public CarED()
        {
            InitializeComponent();
            SetValueForText1 = "";
        }

        public CarED(string id)
        {
            InitializeComponent();
            SetValueForText1 = id;
        }

        private void CarED_Load(object sender, EventArgs e)
        {if (SetValueForText1 == "")
            {
                SetValueForText1 = carreras.SetValueForText1;
            }
           

            if (SetValueForText1 != "")
            {
                FilCB(Int32.Parse(SetValueForText1));
                agregar.Enabled = false;
                editar.Enabled = false;
                edt = true;
                label6.Visible = true;
                modCar();
            }
            else
            {
                SetValueForText1 = "0";
                FilCB(Int32.Parse(SetValueForText1));
                agregar.Enabled = true;
                editar.Enabled = false;

                label6.Visible = true;
            }

           // FilCB(Int32.Parse(SetValueForText1));
            Act = true;


        }

        private void FilCB(int SeT)
        {
            DT2.Rows.Clear();
            Cord_CB.DisplayMember = "";
            Cord_CB.ValueMember = "";

            ConDB cox = new ConDB();

            DT2 = cox.CBcord(SeT);

            Cord_CB.DataSource = DT2;
            
            Cord_CB.DisplayMember = "names";
            Cord_CB.ValueMember = "id";
            Cord_CB.DataSource = DT2;

            Cord_CB.SelectedIndex = -1;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Ed_cord v2 = new Ed_cord();
            v2.ShowDialog();
            Act = false;
    }

        private void CarED_Activated(object sender, EventArgs e)
        {
            if (Act == false)
            {
               FilCB(Int32.Parse(SetValueForText1));
               Act = true;
            }
        }

        private void agregar_Click(object sender, EventArgs e)
        {
            agr_Car();
            
        }

        private void agr_Car()
        {

            int semN = Decimal.ToInt32(sem_N.Value);
            int CTV = Decimal.ToInt32(CT_S.Value);

            if (Nam_TB.Text != "" && textBox2.Text != "" && cl_TB.Text != "" && Cord_CB.SelectedValue.ToString() != "")
            {
                int CBC = Int32.Parse(Cord_CB.SelectedValue.ToString());




                CarDB reg = new CarDB();
                reg.carnew(Nam_TB.Text, textBox2.Text, cl_TB.Text, semN, CTV, CBC);
                this.Close();
            }
            else MessageBox.Show("favor de introducir todos los datos");



        }

        private void Cancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void modCar()
        {
            DataTable RT = new DataTable();
            RT.Rows.Clear();
            CarDB cod = new CarDB();
            RT = cod.regisC(Int32.Parse(SetValueForText1));
            int cord;
            if (RT.Rows.Count == 1)
            {

                Nam_TB.Text = RT.Rows[0][0].ToString();
                cl_TB.Text = RT.Rows[0][1].ToString();
                sem_N.Text = RT.Rows[0][2].ToString();
                CT_S.Text = RT.Rows[0][3].ToString();
                textBox2.Text = RT.Rows[0][4].ToString();
                cord = Int32.Parse(RT.Rows[0][5].ToString());

                
                Cord_CB.SelectedValue = cord;
            }


        }

        private void Cord_CB_SelectedIndexChanged(object sender, EventArgs e)
        {
            label6.Visible = false;
            if (edt) editar.Enabled = true;
        }

        private void editar_Click(object sender, EventArgs e)
        {


            if (Cord_CB.SelectedValue == null)
            {
                MessageBox.Show("seleccionar coordinador");
            }
            else
            {

                int semN = Decimal.ToInt32(sem_N.Value);
                int CTV = Decimal.ToInt32(CT_S.Value);

                int CBC = Int32.Parse(Cord_CB.SelectedValue.ToString());

                if (Nam_TB.Text != "" && textBox2.Text != "" && cl_TB.Text != "" && Cord_CB.SelectedValue.ToString() != "")
                {
                    CarDB cod = new CarDB();
                    cod.modyF(Int32.Parse(SetValueForText1), Nam_TB.Text,
                        textBox2.Text, cl_TB.Text, semN, CTV, CBC);

                    this.Close();
                }
                else MessageBox.Show("favor de introducir todos los datos");
            }

        }
    }
}
