﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public class ConDB
    {
        static private SqlConnection _conexion;
        DataTable RT = new DataTable();

        public DataTable DT = new DataTable();
        public static string SetValueForText1 = "";

        DataTable RTAL = new DataTable();
        static private string ProD2 = "PD_alum";

        DataTable RTAU = new DataTable();
        static private string ProD3 = "PD_aula";

        DataTable RTCA = new DataTable();
        static private string ProD4 = "PD_Car";

        DataTable RTGP = new DataTable();
        static private string ProD5 = "PD_grup";

        DataTable RTM = new DataTable();
        static private string ProD6 = "PD_mat";

        DataTable RTS = new DataTable();
        static private string ProD7 = "PD_sem";

        private DataTable RTT = new DataTable();
        private DataTable DTT1 = new DataTable();
        private DataTable DTT2 = new DataTable();
        private DataTable DTT3 = new DataTable();
        static private string ProD8 = "PD_ALCL";

        DataTable RTR = new DataTable();
        static private string ProD9 = "PD_repo";

        public ConDB() {
            conectar();
        }

        private static void conectar()
        {
            String ConnDB = ConfigurationManager.ConnectionStrings["WindowsFormsApp1.Properties.Settings.Setting"].ConnectionString;

            _conexion = new SqlConnection(ConnDB);
        }

        private static void desconectar()
        {
            _conexion.Close();
        }


        public DataTable auten(string C, string P, string T)
        {
            conectar();
            SqlDataAdapter cmd = new SqlDataAdapter("PD_Adm_Cli", _conexion);
            cmd.SelectCommand.CommandType = CommandType.StoredProcedure;

            cmd.SelectCommand.Parameters.Add("@cla", SqlDbType.Char).Value = C;
            cmd.SelectCommand.Parameters.Add("@pass", SqlDbType.Char).Value = P;

            if (T == "administrador")
            {
                cmd.SelectCommand.Parameters.Add("@opc", SqlDbType.Char).Value = "addm";
            }
            else if (T == "coordinador")
            {
                cmd.SelectCommand.Parameters.Add("@opc", SqlDbType.Char).Value = "cood";
            }

            try
            {


                cmd.Fill(RT);

                desconectar();

            }
            catch (SqlException ex)
            {
                desconectar();
                MessageBox.Show(ex.ToString());
            }

            return RT;
        }

        public DataTable listcord()
        {
            conectar();
            SqlDataAdapter cmd = new SqlDataAdapter("PD_Adm_Cli", _conexion);
            cmd.SelectCommand.CommandType = CommandType.StoredProcedure;

            cmd.SelectCommand.Parameters.Add("@cla", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@pass", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@opc", SqlDbType.Char).Value = "list";

            try
            {


                cmd.Fill(RT);

                desconectar();

            }
            catch (SqlException ex)
            {
                desconectar();
                MessageBox.Show(ex.ToString());
            }

            return RT;
        }

        public void cornew(string Pr, string Sg, string AP, string AM,
            DateTime Nac, string cl, string pas, string nom, string TU)
        {
            try
            {
                conectar();
                SqlCommand cmd = new SqlCommand("PD_Cord", _conexion);

                //cmd.Parameters.Clear();


                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id  ", "");
                cmd.Parameters.AddWithValue("@PrmN", Pr);
                cmd.Parameters.AddWithValue("@SegN", Sg);
                cmd.Parameters.AddWithValue("@ApPa", AP);
                cmd.Parameters.AddWithValue("@ApMA", AM);
                cmd.Parameters.AddWithValue("@Clav", cl);
                cmd.Parameters.AddWithValue("@Pass", pas);
                cmd.Parameters.AddWithValue("@Nomm", nom);
                cmd.Parameters.AddWithValue("@FNac", Nac);
                cmd.Parameters.AddWithValue("@TiUn", TU);
                cmd.Parameters.AddWithValue("@opc", "agre");



                _conexion.Open();

                cmd.ExecuteNonQuery();


                desconectar();
                MessageBox.Show("coordinador registrado");

            }

            catch (SqlException ex)
            {
                desconectar();
                MessageBox.Show(ex.ToString());
            }


        }

        public DataTable regis(int id) {
            DataTable RT = new DataTable();

            SqlDataAdapter cmd = new SqlDataAdapter("PD_Cord", _conexion);
            cmd.SelectCommand.CommandType = CommandType.StoredProcedure;



            cmd.SelectCommand.Parameters.Add("@id", SqlDbType.Char).Value = id;
            cmd.SelectCommand.Parameters.Add("@PrmN", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@SegN", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@ApPa", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@ApMA", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@Clav", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@Pass", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@Nomm", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@FNac", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@TiUn", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@opc", SqlDbType.Char).Value = "see";

            try
            {

                _conexion.Open();


                cmd.Fill(RT);

                _conexion.Close();
            }
            catch (SqlException ex)
            {
                _conexion.Close();
                MessageBox.Show(ex.ToString());
            }


            return RT;
        }

        public void modyF(int i, string Pr, string Sg, string AP, string AM,
            DateTime Nac, string cl, string pas, string nom, string TU) {
            
                try
                {
                    conectar();
                    SqlCommand cmd = new SqlCommand("PD_Cord", _conexion);

                    //cmd.Parameters.Clear();


                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@id  ", i);
                    cmd.Parameters.AddWithValue("@PrmN", Pr);
                    cmd.Parameters.AddWithValue("@SegN", Sg);
                    cmd.Parameters.AddWithValue("@ApPa", AP);
                    cmd.Parameters.AddWithValue("@ApMA", AM);
                    cmd.Parameters.AddWithValue("@Clav", cl);
                    cmd.Parameters.AddWithValue("@Pass", pas);
                    cmd.Parameters.AddWithValue("@Nomm", nom);
                    cmd.Parameters.AddWithValue("@FNac", Nac);
                    cmd.Parameters.AddWithValue("@TiUn", TU);
                    cmd.Parameters.AddWithValue("@opc", "mody");



                    _conexion.Open();

                    cmd.ExecuteNonQuery();


                    desconectar();
                    MessageBox.Show("coordinador modificado");

                }

                catch (SqlException ex)
                {
                    desconectar();
                    MessageBox.Show(ex.ToString());
                }
            
        }

        public DataTable CBcord(int Set) {
            {

                SqlDataAdapter cmd = new SqlDataAdapter("PD_Cord", _conexion);
                cmd.SelectCommand.CommandType = CommandType.StoredProcedure;





                cmd.SelectCommand.Parameters.Add("@id", SqlDbType.Char).Value = Set;
                cmd.SelectCommand.Parameters.Add("@PrmN", SqlDbType.Char).Value = "";
                cmd.SelectCommand.Parameters.Add("@SegN", SqlDbType.Char).Value = "";
                cmd.SelectCommand.Parameters.Add("@ApPa", SqlDbType.Char).Value = "";
                cmd.SelectCommand.Parameters.Add("@ApMA", SqlDbType.Char).Value = "";
                cmd.SelectCommand.Parameters.Add("@Clav", SqlDbType.Char).Value = "";
                cmd.SelectCommand.Parameters.Add("@Pass", SqlDbType.Char).Value = "";
                cmd.SelectCommand.Parameters.Add("@Nomm", SqlDbType.Char).Value = "";
                cmd.SelectCommand.Parameters.Add("@FNac", SqlDbType.Char).Value = "";
                cmd.SelectCommand.Parameters.Add("@TiUn", SqlDbType.Char).Value = "";
                cmd.SelectCommand.Parameters.Add("@opc", SqlDbType.Char).Value = "loo";


                try
                {

                    _conexion.Open();

                    cmd.Fill(RT);



                    _conexion.Close();
                    }
                catch (Exception ex)
                {
                    // write exception info to log or anything else
                    MessageBox.Show(ex.ToString());
                    _conexion.Close();
                }
            }



            return RT;
        }

        public DataTable incor(int id)
        {
            DataTable RT = new DataTable();

            SqlDataAdapter cmd = new SqlDataAdapter("PD_Cord", _conexion);
            cmd.SelectCommand.CommandType = CommandType.StoredProcedure;



            cmd.SelectCommand.Parameters.Add("@id", SqlDbType.Char).Value = id;
            cmd.SelectCommand.Parameters.Add("@PrmN", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@SegN", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@ApPa", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@ApMA", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@Clav", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@Pass", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@Nomm", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@FNac", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@TiUn", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@opc", SqlDbType.Char).Value = "ini";

            try
            {

                _conexion.Open();


                cmd.Fill(RT);

                _conexion.Close();
            }
            catch (SqlException ex)
            {
                _conexion.Close();
                MessageBox.Show(ex.ToString());
            }


            return RT;
        }

        //------------------Alumnos--------------------------------------

        protected DataTable AL_listalumn(int Typ, int ca)
        {

            SqlDataAdapter cmd = new SqlDataAdapter(ProD2, _conexion);
            cmd.SelectCommand.CommandType = CommandType.StoredProcedure;

            cmd.SelectCommand.Parameters.Add("@idal", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@PrmN", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@SegN", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@ApPa", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@ApMA", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@FNac", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@gene", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@LugN", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@prom", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@cred", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@matr", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@idca", SqlDbType.Char).Value = ca;

            if (Typ == 1)
                cmd.SelectCommand.Parameters.Add("@opc", SqlDbType.Char).Value = "lit1";
            else if (Typ == 2)
                cmd.SelectCommand.Parameters.Add("@opc", SqlDbType.Char).Value = "lit2";
            else
                cmd.SelectCommand.Parameters.Add("@opc", SqlDbType.Char).Value = "lit3";
            try
            {


                cmd.Fill(RTAL);

                desconectar();

            }
            catch (SqlException ex)
            {
                desconectar();
                MessageBox.Show(ex.ToString());
            }

            return RTAL;
        }

        protected void AL_novoalum(string Pr, string Sg, string AP, string AM,
          DateTime Nac, string cl, string ubi, string mat, int car)
        {



            try
            {

                SqlCommand cmd = new SqlCommand(ProD2, _conexion);

                //cmd.Parameters.Clear();


                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@idal", "");
                cmd.Parameters.AddWithValue("@PrmN", Pr);
                cmd.Parameters.AddWithValue("@SegN", Sg);
                cmd.Parameters.AddWithValue("@ApPa", AP);
                cmd.Parameters.AddWithValue("@ApMA", AM);
                cmd.Parameters.AddWithValue("@FNac", Nac);
                cmd.Parameters.AddWithValue("@gene", cl);
                cmd.Parameters.AddWithValue("@LugN", ubi);
                cmd.Parameters.AddWithValue("@prom", "");
                cmd.Parameters.AddWithValue("@cred", "");
                cmd.Parameters.AddWithValue("@matr", mat);
                cmd.Parameters.AddWithValue("@idca", car);
                cmd.Parameters.AddWithValue("@opc", "agre");



                _conexion.Open();

                cmd.ExecuteNonQuery();


                desconectar();
                MessageBox.Show("alumno registrado");

            }

            catch (SqlException ex)
            {
                desconectar();
                MessageBox.Show(ex.ToString());
            }


        }

        protected DataTable AL_reg(int Tid)
        {

            SqlDataAdapter cmd = new SqlDataAdapter(ProD2, _conexion);
            cmd.SelectCommand.CommandType = CommandType.StoredProcedure;

            cmd.SelectCommand.Parameters.Add("@idal", SqlDbType.Char).Value = Tid;
            cmd.SelectCommand.Parameters.Add("@PrmN", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@SegN", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@ApPa", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@ApMA", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@FNac", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@gene", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@LugN", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@prom", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@cred", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@matr", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@idca", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@opc", SqlDbType.Char).Value = "see";


            try
            {


                cmd.Fill(RTAL);

                desconectar();

            }
            catch (SqlException ex)
            {
                desconectar();
                MessageBox.Show(ex.ToString());
            }

            return RTAL;


        }


        protected void AL_modyF(int id, string Pr, string Sg, string AP, string AM,
         DateTime Nac, string cl, string ubi, string mat, int car)
        {

            try
            {
                SqlCommand cmd = new SqlCommand(ProD2, _conexion);

                //cmd.Parameters.Clear();


                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@idal", id);
                cmd.Parameters.AddWithValue("@PrmN", Pr);
                cmd.Parameters.AddWithValue("@SegN", Sg);
                cmd.Parameters.AddWithValue("@ApPa", AP);
                cmd.Parameters.AddWithValue("@ApMA", AM);
                cmd.Parameters.AddWithValue("@FNac", Nac);
                cmd.Parameters.AddWithValue("@gene", cl);
                cmd.Parameters.AddWithValue("@LugN", ubi);
                cmd.Parameters.AddWithValue("@prom", "");
                cmd.Parameters.AddWithValue("@cred", "");
                cmd.Parameters.AddWithValue("@matr", mat);
                cmd.Parameters.AddWithValue("@idca", car);
                cmd.Parameters.AddWithValue("@opc", "mody");



                _conexion.Open();

                cmd.ExecuteNonQuery();


                desconectar();
                MessageBox.Show("datos de alumno modifiados");

            }

            catch (SqlException ex)
            {
                desconectar();
                MessageBox.Show(ex.ToString());
            }

        }


        protected void AL_baja(int id)
        {

            try
            {

                SqlCommand cmd = new SqlCommand(ProD2, _conexion);

                //cmd.Parameters.Clear();


                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@idal", id);
                cmd.Parameters.AddWithValue("@PrmN", "");
                cmd.Parameters.AddWithValue("@SegN", "");
                cmd.Parameters.AddWithValue("@ApPa", "");
                cmd.Parameters.AddWithValue("@ApMA", "");
                cmd.Parameters.AddWithValue("@FNac", "");
                cmd.Parameters.AddWithValue("@gene", "");
                cmd.Parameters.AddWithValue("@LugN", "");
                cmd.Parameters.AddWithValue("@prom", "");
                cmd.Parameters.AddWithValue("@cred", "");
                cmd.Parameters.AddWithValue("@matr", "");
                cmd.Parameters.AddWithValue("@idca", "");
                cmd.Parameters.AddWithValue("@opc", "dow");



                _conexion.Open();

                cmd.ExecuteNonQuery();


                desconectar();
                MessageBox.Show("alumno dado de baja");

            }

            catch (SqlException ex)
            {
                desconectar();
                MessageBox.Show(ex.ToString());
            }

        }

        //----------------------------------AULAS
        protected DataTable AU_list()
        {
            SqlDataAdapter cmd = new SqlDataAdapter(ProD3, _conexion);
            cmd.SelectCommand.CommandType = CommandType.StoredProcedure;

            cmd.SelectCommand.Parameters.Add("@id", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@num", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@can", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@opc", SqlDbType.Char).Value = "list";

            try
            {


                cmd.Fill(RTAU);

                desconectar();

            }
            catch (SqlException ex)
            {
                desconectar();
                MessageBox.Show(ex.ToString());
            }

            return RTAU;


        }

        protected DataTable AU_che(int num)
        {
            SqlDataAdapter cmd = new SqlDataAdapter(ProD3, _conexion);
            cmd.SelectCommand.CommandType = CommandType.StoredProcedure;

            cmd.SelectCommand.Parameters.Add("@id", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@num", SqlDbType.Char).Value = num;
            cmd.SelectCommand.Parameters.Add("@can", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@opc", SqlDbType.Char).Value = "che";

            try
            {


                cmd.Fill(RTAU);

                desconectar();

            }
            catch (SqlException ex)
            {
                desconectar();
                MessageBox.Show(ex.ToString());
            }

            return RTAU;


        }

        protected DataTable AU_regis(int id)
        {
            SqlDataAdapter cmd = new SqlDataAdapter(ProD3, _conexion);
            cmd.SelectCommand.CommandType = CommandType.StoredProcedure;

            cmd.SelectCommand.Parameters.Add("@id", SqlDbType.Char).Value = id;
            cmd.SelectCommand.Parameters.Add("@num", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@can", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@opc", SqlDbType.Char).Value = "reg";

            try
            {


                cmd.Fill(RTAU);

                desconectar();

            }
            catch (SqlException ex)
            {
                desconectar();
                MessageBox.Show(ex.ToString());
            }
            return RTAU;



        }

        protected void AU_agreg(int num, int cant)
        {
            try
            {

                SqlCommand cmd = new SqlCommand(ProD3, _conexion);

                //cmd.Parameters.Clear();


                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", "");
                cmd.Parameters.AddWithValue("@num", num);
                cmd.Parameters.AddWithValue("@can", cant);

                cmd.Parameters.AddWithValue("@opc", "NeR");




                _conexion.Open();

                cmd.ExecuteNonQuery();


                desconectar();
                MessageBox.Show("aula registrada");

            }

            catch (SqlException ex)
            {
                desconectar();
                MessageBox.Show(ex.ToString());
            }

        }

        protected void AU_mod(int id, int num, int cant)
        {
            try
            {

                SqlCommand cmd = new SqlCommand(ProD3, _conexion);

                //cmd.Parameters.Clear();


                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", id);
                cmd.Parameters.AddWithValue("@num", num);
                cmd.Parameters.AddWithValue("@can", cant);

                cmd.Parameters.AddWithValue("@opc", "mod");




                _conexion.Open();

                cmd.ExecuteNonQuery();


                desconectar();
                MessageBox.Show("Datos de aula modificados");

            }

            catch (SqlException ex)
            {
                desconectar();
                MessageBox.Show(ex.ToString());
            }

        }

        //--------------------carrera

        protected DataTable CA_listcarr()
        {

            SqlDataAdapter cmd = new SqlDataAdapter(ProD4, _conexion);
            cmd.SelectCommand.CommandType = CommandType.StoredProcedure;

            cmd.SelectCommand.Parameters.Add("@nam", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@des", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@cla", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@C_S", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@CRT", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@IDC", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@IDP", SqlDbType.Char).Value = "";

            cmd.SelectCommand.Parameters.Add("@opc", SqlDbType.Char).Value = "list";

            try
            {


                cmd.Fill(RTCA);

                desconectar();

            }
            catch (SqlException ex)
            {
                desconectar();
                MessageBox.Show(ex.ToString());
            }

            return RTCA;
        }

        protected void CA_carnew(string name, string des, string clave, int C_S, int creditos, int ID_Co)
        {
            try
            {
                conectar();
                SqlCommand cmd = new SqlCommand(ProD4, _conexion);

                //cmd.Parameters.Clear();


                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@nam", name);
                cmd.Parameters.AddWithValue("@des", des);
                cmd.Parameters.AddWithValue("@cla", clave);
                cmd.Parameters.AddWithValue("@C_S", C_S);
                cmd.Parameters.AddWithValue("@CRT", creditos);
                cmd.Parameters.AddWithValue("@IDC", ID_Co);
                cmd.Parameters.AddWithValue("@IDP", "");

                cmd.Parameters.AddWithValue("@opc", "new");




                _conexion.Open();

                cmd.ExecuteNonQuery();


                desconectar();
                MessageBox.Show("carrera agregada");

            }

            catch (SqlException ex)
            {
                desconectar();
                MessageBox.Show(ex.ToString());
            }


        }

        protected DataTable CA_selcar(int id)
        {
            conectar();
            SqlDataAdapter cmd = new SqlDataAdapter(ProD4, _conexion);
            cmd.SelectCommand.CommandType = CommandType.StoredProcedure;

            cmd.SelectCommand.Parameters.Add("@nam", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@des", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@cla", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@C_S", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@CRT", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@IDC", SqlDbType.Char).Value = id;
            cmd.SelectCommand.Parameters.Add("@IDP", SqlDbType.Char).Value = "";

            cmd.SelectCommand.Parameters.Add("@opc", SqlDbType.Char).Value = "sel";

            try
            {


                cmd.Fill(RTCA);

                desconectar();

            }
            catch (SqlException ex)
            {
                desconectar();
                MessageBox.Show(ex.ToString());
            }

            return RTCA;
        }

        protected DataTable CA_regis(int id)
        {


            SqlDataAdapter cmd = new SqlDataAdapter(ProD4, _conexion);
            cmd.SelectCommand.CommandType = CommandType.StoredProcedure;



            cmd.SelectCommand.Parameters.Add("@nam", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@des", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@cla", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@C_S", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@CRT", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@IDC", SqlDbType.Char).Value = id;
            cmd.SelectCommand.Parameters.Add("@IDP", SqlDbType.Char).Value = id;

            cmd.SelectCommand.Parameters.Add("@opc", SqlDbType.Char).Value = "yen";


            try
            {

                _conexion.Open();


                cmd.Fill(RTCA);

                _conexion.Close();
            }
            catch (SqlException ex)
            {
                _conexion.Close();
                MessageBox.Show(ex.ToString());
            }


            return RTCA;
        }

        protected void CA_modyF(int id, string name, string des, string clave, int C_S, int creditos, int ID_Co)
        {

            try
            {
                conectar();
                SqlCommand cmd = new SqlCommand(ProD4, _conexion);

                //cmd.Parameters.Clear();




                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@nam", name);
                cmd.Parameters.AddWithValue("@des", des);
                cmd.Parameters.AddWithValue("@cla", clave);
                cmd.Parameters.AddWithValue("@C_S", C_S);
                cmd.Parameters.AddWithValue("@CRT", creditos);
                cmd.Parameters.AddWithValue("@IDC", ID_Co);
                cmd.Parameters.AddWithValue("@IDP", id);

                cmd.Parameters.AddWithValue("@opc", "udp");



                _conexion.Open();

                cmd.ExecuteNonQuery();


                desconectar();
                MessageBox.Show("coordinador modificado");

            }

            catch (SqlException ex)
            {
                desconectar();
                MessageBox.Show(ex.ToString());
            }

        }

        protected DataTable CA_CBcar_A(int id)
        {



            SqlDataAdapter cmd = new SqlDataAdapter(ProD4, _conexion);
            cmd.SelectCommand.CommandType = CommandType.StoredProcedure;



            cmd.SelectCommand.Parameters.Add("@nam", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@des", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@cla", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@C_S", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@CRT", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@IDP", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@IDC", SqlDbType.Char).Value = id;
            if (id == 0)
                cmd.SelectCommand.Parameters.Add("@opc", SqlDbType.Char).Value = "CBA";
            else
                cmd.SelectCommand.Parameters.Add("@opc", SqlDbType.Char).Value = "CBC";

            try
            {

                _conexion.Open();


                cmd.Fill(RTCA);

                _conexion.Close();
            }
            catch (SqlException ex)
            {
                _conexion.Close();
                MessageBox.Show(ex.ToString());
            }


            return RTCA;

        }

        protected DataTable CA_listcarrfalt()
        {

            SqlDataAdapter cmd = new SqlDataAdapter(ProD4, _conexion);
            cmd.SelectCommand.CommandType = CommandType.StoredProcedure;

            cmd.SelectCommand.Parameters.Add("@nam", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@des", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@cla", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@C_S", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@CRT", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@IDC", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@IDP", SqlDbType.Char).Value = "";

            cmd.SelectCommand.Parameters.Add("@opc", SqlDbType.Char).Value = "fal";

            try
            {


                cmd.Fill(RTCA);

                desconectar();

            }
            catch (SqlException ex)
            {
                desconectar();
                MessageBox.Show(ex.ToString());
            }

            return RTCA;
        }

        //---------------grupo
        protected DataTable GP_listtotal(int sem)
        {
            conectar();
            SqlDataAdapter cmd = new SqlDataAdapter(ProD5, _conexion);
            cmd.SelectCommand.CommandType = CommandType.StoredProcedure;

            cmd.SelectCommand.Parameters.Add("@idG", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@idA", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@idM", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@idE", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@idS", SqlDbType.Char).Value = sem;
            cmd.SelectCommand.Parameters.Add("@opc", SqlDbType.Char).Value = "lisG";


            try
            {


                cmd.Fill(RTGP);

                desconectar();

            }
            catch (SqlException ex)
            {
                desconectar();
                MessageBox.Show(ex.ToString());
            }

            return RTGP;
        }

        protected DataTable GP_listaula()
        {
            conectar();
            SqlDataAdapter cmd = new SqlDataAdapter(ProD5, _conexion);
            cmd.SelectCommand.CommandType = CommandType.StoredProcedure;

            cmd.SelectCommand.Parameters.Add("@idG", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@idA", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@idM", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@idE", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@idS", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@opc", SqlDbType.Char).Value = "lisA";


            try
            {


                cmd.Fill(RTGP);

                desconectar();

            }
            catch (SqlException ex)
            {
                desconectar();
                MessageBox.Show(ex.ToString());
            }

            return RTGP;
        }

        protected DataTable GP_listmat()
        {
            conectar();
            SqlDataAdapter cmd = new SqlDataAdapter(ProD5, _conexion);
            cmd.SelectCommand.CommandType = CommandType.StoredProcedure;

            cmd.SelectCommand.Parameters.Add("@idG", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@idA", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@idM", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@idE", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@idS", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@opc", SqlDbType.Char).Value = "lisM";


            try
            {


                cmd.Fill(RTGP);

                desconectar();

            }
            catch (SqlException ex)
            {
                desconectar();
                MessageBox.Show(ex.ToString());
            }

            return RTGP;
        }

        protected DataTable GP_horas(int idA, int sem)
        {
            conectar();
            SqlDataAdapter cmd = new SqlDataAdapter(ProD5, _conexion);
            cmd.SelectCommand.CommandType = CommandType.StoredProcedure;

            cmd.SelectCommand.Parameters.Add("@idG", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@idA", SqlDbType.Char).Value = idA;
            cmd.SelectCommand.Parameters.Add("@idM", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@idE", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@idS", SqlDbType.Char).Value = sem;
            cmd.SelectCommand.Parameters.Add("@opc", SqlDbType.Char).Value = "lisH";


            try
            {


                cmd.Fill(RTGP);

                desconectar();

            }
            catch (SqlException ex)
            {
                desconectar();
                MessageBox.Show(ex.ToString());
            }

            return RTGP;
        }

        protected void GP_novcls(int A, int S, int M, int G)
        {


            try
            {
                conectar();
                SqlCommand cmd = new SqlCommand(ProD5, _conexion);

                //cmd.Parameters.Clear();


                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@idG",G);
                cmd.Parameters.AddWithValue("@idA",A);
                cmd.Parameters.AddWithValue("@idM",M);
                cmd.Parameters.AddWithValue("@idE","");
                cmd.Parameters.AddWithValue("@idS",S);
                cmd.Parameters.AddWithValue("@opc","Nov");



                _conexion.Open();

                cmd.ExecuteNonQuery();


                desconectar();
                MessageBox.Show("clase creada");

            }

            catch (SqlException ex)
            {
                desconectar();
                MessageBox.Show(ex.ToString());
            }


        }

        protected DataTable GP_modde(int id)
        {
            conectar();
            SqlDataAdapter cmd = new SqlDataAdapter(ProD5, _conexion);
            cmd.SelectCommand.CommandType = CommandType.StoredProcedure;

            cmd.SelectCommand.Parameters.Add("@idG", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@idA", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@idM", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@idE", SqlDbType.Char).Value = id;
            cmd.SelectCommand.Parameters.Add("@idS", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@opc", SqlDbType.Char).Value = "mod";


            try
            {


                cmd.Fill(RTGP);

                desconectar();

            }
            catch (SqlException ex)
            {
                desconectar();
                MessageBox.Show(ex.ToString());
            }

            return RTGP;
        }

        protected DataTable GP_chgr(int id,int aul, int gpo,int mat)
        {
            conectar();
            SqlDataAdapter cmd = new SqlDataAdapter(ProD5, _conexion);
            cmd.SelectCommand.CommandType = CommandType.StoredProcedure;

            cmd.SelectCommand.Parameters.Add("@idG", SqlDbType.Char).Value = gpo;
            cmd.SelectCommand.Parameters.Add("@idA", SqlDbType.Char).Value = aul;
            cmd.SelectCommand.Parameters.Add("@idM", SqlDbType.Char).Value = mat;
            cmd.SelectCommand.Parameters.Add("@idE", SqlDbType.Char).Value = id;
            cmd.SelectCommand.Parameters.Add("@idS", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@opc", SqlDbType.Char).Value = "udp";


            try
            {


                cmd.Fill(RTGP);

                desconectar();

            }
            catch (SqlException ex)
            {
                desconectar();
                MessageBox.Show(ex.ToString());
            }

            return RTGP;
        }

        protected DataTable GP_listgr(int sem)
        {
            conectar();
            SqlDataAdapter cmd = new SqlDataAdapter(ProD5, _conexion);
            cmd.SelectCommand.CommandType = CommandType.StoredProcedure;

            cmd.SelectCommand.Parameters.Add("@idG", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@idA", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@idM", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@idE", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@idS", SqlDbType.Char).Value = sem;
            cmd.SelectCommand.Parameters.Add("@opc", SqlDbType.Char).Value = "Glis";


            try
            {


                cmd.Fill(RTGP);

                desconectar();

            }
            catch (SqlException ex)
            {
                desconectar();
                MessageBox.Show(ex.ToString());
            }

            return RTGP;
        }


        //-------------------------materia

        protected void M_novoalum(string nombre, string clave, int cred, int HS, int carr, string desc)
        {


            try
            {
                conectar();
                SqlCommand cmd = new SqlCommand(ProD6, _conexion);

                //cmd.Parameters.Clear();


                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", "");
                cmd.Parameters.AddWithValue("@nam", nombre);
                cmd.Parameters.AddWithValue("@des", desc);
                cmd.Parameters.AddWithValue("@clv", clave);
                cmd.Parameters.AddWithValue("@crd", cred);
                cmd.Parameters.AddWithValue("@HpS", HS);
                cmd.Parameters.AddWithValue("@sem", "");
                cmd.Parameters.AddWithValue("@IDC", carr);
                cmd.Parameters.AddWithValue("@opc", "agre");




                _conexion.Open();

                cmd.ExecuteNonQuery();


                desconectar();
                MessageBox.Show("materia creada");

            }

            catch (SqlException ex)
            {
                desconectar();
                MessageBox.Show(ex.ToString());
            }


        }

        protected DataTable M_lista(int id, int typ)
        {
            conectar();
            SqlDataAdapter cmd = new SqlDataAdapter(ProD6, _conexion);
            cmd.SelectCommand.CommandType = CommandType.StoredProcedure;

            cmd.SelectCommand.Parameters.Add("@id", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@nam", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@des", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@clv", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@crd", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@HpS", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@sem", SqlDbType.Char).Value = "";


            if (typ == 0)
            {
                cmd.SelectCommand.Parameters.Add("@opc", SqlDbType.Char).Value = "list";
                cmd.SelectCommand.Parameters.Add("@IDC", SqlDbType.Char).Value = "";
            }
            else
            {
                cmd.SelectCommand.Parameters.Add("@opc", SqlDbType.Char).Value = "lipe";
                cmd.SelectCommand.Parameters.Add("@IDC", SqlDbType.Char).Value = id;
            }

            try
            {


                cmd.Fill(RTM);

                desconectar();

            }
            catch (SqlException ex)
            {
                desconectar();
                MessageBox.Show(ex.ToString());
            }

            return RTM;
        }

        protected DataTable M_regis(int id)
        {


            SqlDataAdapter cmd = new SqlDataAdapter(ProD6, _conexion);
            cmd.SelectCommand.CommandType = CommandType.StoredProcedure;



            cmd.SelectCommand.Parameters.Add("@id", SqlDbType.Char).Value = id;
            cmd.SelectCommand.Parameters.Add("@nam", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@des", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@clv", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@crd", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@HpS", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@sem", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@IDC", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@opc", SqlDbType.Char).Value = "sele";


            try
            {

                _conexion.Open();


                cmd.Fill(RTM);

                _conexion.Close();
            }
            catch (SqlException ex)
            {
                _conexion.Close();
                MessageBox.Show(ex.ToString());
            }


            return RTM;
        }

        protected void M_modreg(int id, string nombre, string clave, int cred, int HS, int carr, string desc)
        {


            try
            {
                conectar();
                SqlCommand cmd = new SqlCommand(ProD6, _conexion);

                //cmd.Parameters.Clear();


                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", id);
                cmd.Parameters.AddWithValue("@nam", nombre);
                cmd.Parameters.AddWithValue("@des", desc);
                cmd.Parameters.AddWithValue("@clv", clave);
                cmd.Parameters.AddWithValue("@crd", cred);
                cmd.Parameters.AddWithValue("@HpS", HS);
                cmd.Parameters.AddWithValue("@sem", "");
                cmd.Parameters.AddWithValue("@IDC", carr);
                cmd.Parameters.AddWithValue("@opc", "udp");




                _conexion.Open();

                cmd.ExecuteNonQuery();


                desconectar();
                MessageBox.Show("materia modificada");

            }

            catch (SqlException ex)
            {
                desconectar();
                MessageBox.Show(ex.ToString());
            }


        }

        protected DataTable M_lista2()
        {
            conectar();
            SqlDataAdapter cmd = new SqlDataAdapter(ProD6, _conexion);
            cmd.SelectCommand.CommandType = CommandType.StoredProcedure;

            cmd.SelectCommand.Parameters.Add("@id", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@nam", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@des", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@clv", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@crd", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@HpS", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@sem", SqlDbType.Char).Value = "";



            cmd.SelectCommand.Parameters.Add("@opc", SqlDbType.Char).Value = "lis2";
            cmd.SelectCommand.Parameters.Add("@IDC", SqlDbType.Char).Value = "";

            try
            {


                cmd.Fill(RTM);

                desconectar();

            }
            catch (SqlException ex)
            {
                desconectar();
                MessageBox.Show(ex.ToString());
            }

            return RTM;
        }



        //--------------semestre


        protected DataTable S_perAct()
        {


            SqlDataAdapter cmd = new SqlDataAdapter(ProD7, _conexion);
            cmd.SelectCommand.CommandType = CommandType.StoredProcedure;



            cmd.SelectCommand.Parameters.Add("@id", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@fech", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@desc", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@adm", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@ced", SqlDbType.Char).Value = "";

            cmd.SelectCommand.Parameters.Add("@opc", SqlDbType.Char).Value = "est";





            try
            {

                _conexion.Open();


                cmd.Fill(RTS);

                _conexion.Close();
            }
            catch (SqlException ex)
            {
                _conexion.Close();
                MessageBox.Show(ex.ToString());
            }


            return RTS;
        }

        protected DataTable S_fillCB()
        {


            SqlDataAdapter cmd = new SqlDataAdapter(ProD7, _conexion);
            cmd.SelectCommand.CommandType = CommandType.StoredProcedure;



            cmd.SelectCommand.Parameters.Add("@id", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@fech", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@desc", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@adm", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@ced", SqlDbType.Char).Value = "";

            cmd.SelectCommand.Parameters.Add("@opc", SqlDbType.Char).Value = "list";





            try
            {

                _conexion.Open();


                cmd.Fill(RTS);

                _conexion.Close();
            }
            catch (SqlException ex)
            {
                _conexion.Close();
                MessageBox.Show(ex.ToString());
            }


            return RTS;
        }

        protected void S_CerIns(int id)
        {

            try
            {
                conectar();
                SqlCommand cmd = new SqlCommand(ProD7, _conexion);

                //cmd.Parameters.Clear();




                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", id);
                cmd.Parameters.AddWithValue("@fech", "");
                cmd.Parameters.AddWithValue("@desc", "");
                cmd.Parameters.AddWithValue("@adm", "");
                cmd.Parameters.AddWithValue("@ced", "");
                cmd.Parameters.AddWithValue("@opc", "cls");





                _conexion.Open();

                cmd.ExecuteNonQuery();


                desconectar();
                MessageBox.Show("estado del Periodo modificado");

            }

            catch (SqlException ex)
            {
                desconectar();
                MessageBox.Show(ex.ToString());
            }

        }

        protected void S_FinSem(int id)
        {

            try
            {
                conectar();
                SqlCommand cmd = new SqlCommand(ProD7, _conexion);

                //cmd.Parameters.Clear();




                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", id);
                cmd.Parameters.AddWithValue("@fech", "");
                cmd.Parameters.AddWithValue("@desc", "");
                cmd.Parameters.AddWithValue("@adm", "");
                cmd.Parameters.AddWithValue("@ced", "");
                cmd.Parameters.AddWithValue("@opc", "end");





                _conexion.Open();

                cmd.ExecuteNonQuery();


                desconectar();
                MessageBox.Show("estado del Periodo modificado");

            }

            catch (SqlException ex)
            {
                desconectar();
                MessageBox.Show(ex.ToString());
            }

        }

        protected void S_newSem(string desc, int id)
        {
            try
            {
                conectar();
                SqlCommand cmd = new SqlCommand(ProD7, _conexion);

                //cmd.Parameters.Clear();

                int año;

                año = Int32.Parse(desc);

                cmd.CommandType = CommandType.StoredProcedure;


                if ((id % 2) == 0)
                {
                    cmd.Parameters.AddWithValue("@opc", "ne2");
                }
                else
                {

                    cmd.Parameters.AddWithValue("@opc", "ne1");
                    año++;
                }

                cmd.Parameters.AddWithValue("@id", "");
                cmd.Parameters.AddWithValue("@fech", "");
                cmd.Parameters.AddWithValue("@desc", año);
                cmd.Parameters.AddWithValue("@ced", 0);
                cmd.Parameters.AddWithValue("@adm", "");






                _conexion.Open();

                cmd.ExecuteNonQuery();


                desconectar();
                MessageBox.Show("semestre creado");

            }

            catch (SqlException ex)
            {
                desconectar();
                MessageBox.Show(ex.ToString());
            }

        }

        protected DataTable S_compr(string desc)
        {
            DataTable RT = new DataTable();

            SqlDataAdapter cmd = new SqlDataAdapter(ProD7, _conexion);
            cmd.SelectCommand.CommandType = CommandType.StoredProcedure;



            cmd.SelectCommand.Parameters.Add("@id", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@fech", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@desc", SqlDbType.Char).Value = desc;
            cmd.SelectCommand.Parameters.Add("@adm", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@ced", SqlDbType.Char).Value = "";

            cmd.SelectCommand.Parameters.Add("@opc", SqlDbType.Char).Value = "comp";





            try
            {

                _conexion.Open();


                cmd.Fill(RT);

                _conexion.Close();
            }
            catch (SqlException ex)
            {
                _conexion.Close();
                MessageBox.Show(ex.ToString());
            }


            return RT;
        }

        protected void S_newSem2(string desc, int ced)
        {
            try
            {
                conectar();
                SqlCommand cmd = new SqlCommand(ProD7, _conexion);

                //cmd.Parameters.Clear();



                cmd.CommandType = CommandType.StoredProcedure;




                cmd.Parameters.AddWithValue("@id", "");
                cmd.Parameters.AddWithValue("@fech", "");
                cmd.Parameters.AddWithValue("@desc", desc);
                cmd.Parameters.AddWithValue("@adm", "");
                cmd.Parameters.AddWithValue("@ced", ced);
                cmd.Parameters.AddWithValue("@opc", "ne3");





                _conexion.Open();

                cmd.ExecuteNonQuery();


                desconectar();
                MessageBox.Show("semestre creado");

            }

            catch (SqlException ex)
            {
                desconectar();
                MessageBox.Show(ex.ToString());
            }

        }

        //-------------------TAC

        protected DataTable T_list1(int Typ)
        {
            conectar();
            SqlDataAdapter cmd = new SqlDataAdapter(ProD8, _conexion);
            cmd.SelectCommand.CommandType = CommandType.StoredProcedure;

            cmd.SelectCommand.Parameters.Add("@idG", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@idC", SqlDbType.Char).Value = Typ;
            cmd.SelectCommand.Parameters.Add("@idA", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@cal", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@P_E", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@opc", SqlDbType.Char).Value = "list";
            try
            {


                cmd.Fill(RTT);

                desconectar();

            }
            catch (SqlException ex)
            {
                desconectar();
                MessageBox.Show(ex.ToString());
            }

            return RTT;
        }

        protected DataTable T_list2(int Typ, int sem)
        {
            conectar();
            SqlDataAdapter cmd = new SqlDataAdapter(ProD8, _conexion);
            cmd.SelectCommand.CommandType = CommandType.StoredProcedure;

            cmd.SelectCommand.Parameters.Add("@idG", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@idC", SqlDbType.Char).Value = Typ;
            cmd.SelectCommand.Parameters.Add("@idA", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@cal", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@P_E", SqlDbType.Char).Value = sem;
            cmd.SelectCommand.Parameters.Add("@opc", SqlDbType.Char).Value = "lis2";
            try
            {


                cmd.Fill(RTT);

                desconectar();

            }
            catch (SqlException ex)
            {
                desconectar();
                MessageBox.Show(ex.ToString());
            }

            return RTT;
        }

        protected DataTable T_list3(int Typ, int sem)
        {
            conectar();
            SqlDataAdapter cmd = new SqlDataAdapter(ProD8, _conexion);
            cmd.SelectCommand.CommandType = CommandType.StoredProcedure;

            cmd.SelectCommand.Parameters.Add("@idG", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@idC", SqlDbType.Char).Value = Typ;
            cmd.SelectCommand.Parameters.Add("@idA", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@cal", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@P_E", SqlDbType.Char).Value = sem;
            cmd.SelectCommand.Parameters.Add("@opc", SqlDbType.Char).Value = "lis3";
            try
            {


                cmd.Fill(RTT);

                desconectar();

            }
            catch (SqlException ex)
            {
                desconectar();
                MessageBox.Show(ex.ToString());
            }

            return RTT;
        }

        protected DataTable T_comp(int ida, int idg)
        {
            conectar();
            SqlDataAdapter cmd = new SqlDataAdapter(ProD8, _conexion);
            cmd.SelectCommand.CommandType = CommandType.StoredProcedure;

            cmd.SelectCommand.Parameters.Add("@idG", SqlDbType.Char).Value = idg;
            cmd.SelectCommand.Parameters.Add("@idC", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@idA", SqlDbType.Char).Value = ida;
            cmd.SelectCommand.Parameters.Add("@cal", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@P_E", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@opc", SqlDbType.Char).Value = "comp";
            try
            {


                cmd.Fill(DTT1);

                desconectar();

            }
            catch (SqlException ex)
            {
                desconectar();
                MessageBox.Show(ex.ToString());
            }

            return DTT1;
        }

        protected DataTable T_max(int idg)
        {
            conectar();
            SqlDataAdapter cmd = new SqlDataAdapter(ProD8, _conexion);
            cmd.SelectCommand.CommandType = CommandType.StoredProcedure;

            cmd.SelectCommand.Parameters.Add("@idG", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@idC", SqlDbType.Char).Value = idg;
            cmd.SelectCommand.Parameters.Add("@idA", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@cal", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@P_E", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@opc", SqlDbType.Char).Value = "max";
            try
            {


                cmd.Fill(DTT2);

                desconectar();

            }
            catch (SqlException ex)
            {
                desconectar();
                MessageBox.Show(ex.ToString());
            }

            return DTT2;
        }

        protected DataTable T_total(int ida)
        {
            conectar();
            SqlDataAdapter cmd = new SqlDataAdapter(ProD8, _conexion);
            cmd.SelectCommand.CommandType = CommandType.StoredProcedure;

            cmd.SelectCommand.Parameters.Add("@idG", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@idC", SqlDbType.Char).Value = ida;
            cmd.SelectCommand.Parameters.Add("@idA", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@cal", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@P_E", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@opc", SqlDbType.Char).Value = "con";
            try
            {


                cmd.Fill(DTT3);

                desconectar();

            }
            catch (SqlException ex)
            {
                desconectar();
                MessageBox.Show(ex.ToString());
            }

            return DTT3;
        }

        protected void T_regist(int ida, int sem, int idC)
        {

            try
            {
                conectar();
                SqlCommand cmd = new SqlCommand(ProD8, _conexion);

                //cmd.Parameters.Clear();


                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@idG", idC);
                cmd.Parameters.AddWithValue("@idC", "");
                cmd.Parameters.AddWithValue("@idA", ida);
                cmd.Parameters.AddWithValue("@cal", "");
                cmd.Parameters.AddWithValue("@P_E", sem);
                cmd.Parameters.AddWithValue("@opc", "nov");




                _conexion.Open();

                cmd.ExecuteNonQuery();


                desconectar();
                MessageBox.Show("alumno registrado");

            }

            catch (SqlException ex)
            {
                desconectar();
                MessageBox.Show(ex.ToString());
            }

        }

        protected void T_borra(int ida, int idC)
        {

            try
            {
                conectar();
                SqlCommand cmd = new SqlCommand(ProD8, _conexion);

                //cmd.Parameters.Clear();


                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@idG", idC);
                cmd.Parameters.AddWithValue("@idC", "");
                cmd.Parameters.AddWithValue("@idA", ida);
                cmd.Parameters.AddWithValue("@cal", "");
                cmd.Parameters.AddWithValue("@P_E", "");
                cmd.Parameters.AddWithValue("@opc", "borr");




                _conexion.Open();

                cmd.ExecuteNonQuery();


                desconectar();
            }

            catch (SqlException ex)
            {
                desconectar();
                MessageBox.Show(ex.ToString());
            }

        }

        protected void T_final()
        {
            try
            {
                conectar();
                SqlCommand cmd = new SqlCommand(ProD8, _conexion);

                //cmd.Parameters.Clear();


                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@idG", "");
                cmd.Parameters.AddWithValue("@idC", "");
                cmd.Parameters.AddWithValue("@idA", "");
                cmd.Parameters.AddWithValue("@cal", "");
                cmd.Parameters.AddWithValue("@P_E", "");
                cmd.Parameters.AddWithValue("@opc", "end");




                _conexion.Open();

                cmd.ExecuteNonQuery();


                desconectar();
            }

            catch (SqlException ex)
            {
                desconectar();
                MessageBox.Show(ex.ToString());
            }
        }

        protected DataTable T_pase(int ida, int idM)
        {
            conectar();
            SqlDataAdapter cmd = new SqlDataAdapter(ProD8, _conexion);
            cmd.SelectCommand.CommandType = CommandType.StoredProcedure;

            cmd.SelectCommand.Parameters.Add("@idG", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@idC", SqlDbType.Char).Value = idM;
            cmd.SelectCommand.Parameters.Add("@idA", SqlDbType.Char).Value = ida;
            cmd.SelectCommand.Parameters.Add("@cal", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@P_E", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@opc", SqlDbType.Char).Value = "pas";
            try
            {


                cmd.Fill(RTT);

                desconectar();

            }
            catch (SqlException ex)
            {
                desconectar();
                MessageBox.Show(ex.ToString());
            }

            return RTT;
        }

        protected DataTable T_chefin(int sem)
        {
            conectar();
            SqlDataAdapter cmd = new SqlDataAdapter(ProD8, _conexion);
            cmd.SelectCommand.CommandType = CommandType.StoredProcedure;

            cmd.SelectCommand.Parameters.Add("@idG", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@idC", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@idA", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@cal", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@P_E", SqlDbType.Char).Value = sem;
            cmd.SelectCommand.Parameters.Add("@opc", SqlDbType.Char).Value = "chk";
            try
            {


                cmd.Fill(RTT);

                desconectar();

            }
            catch (SqlException ex)
            {
                desconectar();
                MessageBox.Show(ex.ToString());
            }

            return RTT;
        }

        protected DataTable T_regm(int idg)
        {
            conectar();
            SqlDataAdapter cmd = new SqlDataAdapter(ProD8, _conexion);
            cmd.SelectCommand.CommandType = CommandType.StoredProcedure;

            cmd.SelectCommand.Parameters.Add("@idG", SqlDbType.Char).Value = idg;
            cmd.SelectCommand.Parameters.Add("@idC", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@idA", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@cal", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@P_E", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@opc", SqlDbType.Char).Value = "mo2";
            try
            {


                cmd.Fill(DTT2);

                desconectar();

            }
            catch (SqlException ex)
            {
                desconectar();
                MessageBox.Show(ex.ToString());
            }

            return DTT2;
        }

        protected void T_modcal(int sem, int idC)
        {

            try
            {
                conectar();
                SqlCommand cmd = new SqlCommand(ProD8, _conexion);

                //cmd.Parameters.Clear();


                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@idG", "");
                cmd.Parameters.AddWithValue("@idC", idC);
                cmd.Parameters.AddWithValue("@idA", "");
                cmd.Parameters.AddWithValue("@cal", sem);
                cmd.Parameters.AddWithValue("@P_E", "");
                cmd.Parameters.AddWithValue("@opc", "mca");




                _conexion.Open();

                cmd.ExecuteNonQuery();


                desconectar();
                MessageBox.Show("calificacion aplicada");

            }

            catch (SqlException ex)
            {
                desconectar();
                MessageBox.Show(ex.ToString());
            }

        }


        protected DataTable T_cred(int ida,int sem)
        {
            conectar();
            DataTable crt = new DataTable();
            SqlDataAdapter cmd = new SqlDataAdapter(ProD8, _conexion);
            cmd.SelectCommand.CommandType = CommandType.StoredProcedure;

            cmd.SelectCommand.Parameters.Add("@idG", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@idC", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@idA", SqlDbType.Char).Value = ida;
            cmd.SelectCommand.Parameters.Add("@cal", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@P_E", SqlDbType.Char).Value = sem;
            cmd.SelectCommand.Parameters.Add("@opc", SqlDbType.Char).Value = "cre";
            try
            {


                cmd.Fill(crt);

                desconectar();

            }
            catch (SqlException ex)
            {
                desconectar();
                MessageBox.Show(ex.ToString());
            }

            return crt;
        }


        protected DataTable T_sem(int sem)
        {
            conectar();
            DataTable crt = new DataTable();
            SqlDataAdapter cmd = new SqlDataAdapter(ProD8, _conexion);
            cmd.SelectCommand.CommandType = CommandType.StoredProcedure;

            cmd.SelectCommand.Parameters.Add("@idG", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@idC", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@idA", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@cal", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@P_E", SqlDbType.Char).Value = sem;
            cmd.SelectCommand.Parameters.Add("@opc", SqlDbType.Char).Value = "sem";
            try
            {


                cmd.Fill(crt);

                desconectar();

            }
            catch (SqlException ex)
            {
                desconectar();
                MessageBox.Show(ex.ToString());
            }

            return crt;
        }

        protected DataTable T_cM(int idg)
        {
            conectar();
            DataTable crt = new DataTable();
            SqlDataAdapter cmd = new SqlDataAdapter(ProD8, _conexion);
            cmd.SelectCommand.CommandType = CommandType.StoredProcedure;

            cmd.SelectCommand.Parameters.Add("@idG", SqlDbType.Char).Value = idg;
            cmd.SelectCommand.Parameters.Add("@idC", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@idA", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@cal", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@P_E", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@opc", SqlDbType.Char).Value = "mcr";
            try
            {


                cmd.Fill(crt);

                desconectar();

            }
            catch (SqlException ex)
            {
                desconectar();
                MessageBox.Show(ex.ToString());
            }

            return crt;
        }

        //--------------------------reportes
        protected DataTable R_kar(int idC)
        {

            SqlDataAdapter cmd = new SqlDataAdapter(ProD9, _conexion);
            cmd.SelectCommand.CommandType = CommandType.StoredProcedure;

            cmd.SelectCommand.Parameters.Add("@idal", SqlDbType.Char).Value = idC;
            cmd.SelectCommand.Parameters.Add("@idPE", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@idca", SqlDbType.Char).Value = "";

            cmd.SelectCommand.Parameters.Add("@opc", SqlDbType.Char).Value = "kad";
            try
            {


                cmd.Fill(RTR);

                desconectar();

            }
            catch (SqlException ex)
            {
                desconectar();
                MessageBox.Show(ex.ToString());
            }

            return RTR;
        }

        protected DataTable R_repA1()
        {

            SqlDataAdapter cmd = new SqlDataAdapter(ProD9, _conexion);
            cmd.SelectCommand.CommandType = CommandType.StoredProcedure;

            cmd.SelectCommand.Parameters.Add("@idal", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@idPE", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@idca", SqlDbType.Char).Value = "";

            cmd.SelectCommand.Parameters.Add("@opc", SqlDbType.Char).Value = "prS1";
            try
            {


                cmd.Fill(RTR);

                desconectar();

            }
            catch (SqlException ex)
            {
                desconectar();
                MessageBox.Show(ex.ToString());
            }

            return RTR;
        }

        protected DataTable R_repA2()
        {

            SqlDataAdapter cmd = new SqlDataAdapter(ProD9, _conexion);
            cmd.SelectCommand.CommandType = CommandType.StoredProcedure;

            cmd.SelectCommand.Parameters.Add("@idal", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@idPE", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@idca", SqlDbType.Char).Value = "";

            cmd.SelectCommand.Parameters.Add("@opc", SqlDbType.Char).Value = "prS2";
            try
            {


                cmd.Fill(RTR);

                desconectar();

            }
            catch (SqlException ex)
            {
                desconectar();
                MessageBox.Show(ex.ToString());
            }

            return RTR;
        }

        protected DataTable R_repA3()
        {

            SqlDataAdapter cmd = new SqlDataAdapter(ProD9, _conexion);
            cmd.SelectCommand.CommandType = CommandType.StoredProcedure;

            cmd.SelectCommand.Parameters.Add("@idal", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@idPE", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@idca", SqlDbType.Char).Value = "";

            cmd.SelectCommand.Parameters.Add("@opc", SqlDbType.Char).Value = "prS3";
            try
            {


                cmd.Fill(RTR);

                desconectar();

            }
            catch (SqlException ex)
            {
                desconectar();
                MessageBox.Show(ex.ToString());
            }

            return RTR;
        }

        protected DataTable R_repA4()
        {

            SqlDataAdapter cmd = new SqlDataAdapter(ProD9, _conexion);
            cmd.SelectCommand.CommandType = CommandType.StoredProcedure;

            cmd.SelectCommand.Parameters.Add("@idal", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@idPE", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@idca", SqlDbType.Char).Value = "";

            cmd.SelectCommand.Parameters.Add("@opc", SqlDbType.Char).Value = "prS4";
            try
            {


                cmd.Fill(RTR);

                desconectar();

            }
            catch (SqlException ex)
            {
                desconectar();
                MessageBox.Show(ex.ToString());
            }

            return RTR;
        }

        protected DataTable R_repC1()
        {

            SqlDataAdapter cmd = new SqlDataAdapter(ProD9, _conexion);
            cmd.SelectCommand.CommandType = CommandType.StoredProcedure;

            cmd.SelectCommand.Parameters.Add("@idal", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@idPE", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@idca", SqlDbType.Char).Value = "";

            cmd.SelectCommand.Parameters.Add("@opc", SqlDbType.Char).Value = "prC1";
            try
            {


                cmd.Fill(RTR);

                desconectar();

            }
            catch (SqlException ex)
            {
                desconectar();
                MessageBox.Show(ex.ToString());
            }

            return RTR;
        }

        protected DataTable R_repC2()
        {

            SqlDataAdapter cmd = new SqlDataAdapter(ProD9, _conexion);
            cmd.SelectCommand.CommandType = CommandType.StoredProcedure;

            cmd.SelectCommand.Parameters.Add("@idal", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@idPE", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@idca", SqlDbType.Char).Value = "";

            cmd.SelectCommand.Parameters.Add("@opc", SqlDbType.Char).Value = "prC2";
            try
            {


                cmd.Fill(RTR);

                desconectar();

            }
            catch (SqlException ex)
            {
                desconectar();
                MessageBox.Show(ex.ToString());
            }

            return RTR;
        }

        protected DataTable R_repM1()
        {

            SqlDataAdapter cmd = new SqlDataAdapter(ProD9, _conexion);
            cmd.SelectCommand.CommandType = CommandType.StoredProcedure;

            cmd.SelectCommand.Parameters.Add("@idal", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@idPE", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@idca", SqlDbType.Char).Value = "";

            cmd.SelectCommand.Parameters.Add("@opc", SqlDbType.Char).Value = "prM1";
            try
            {


                cmd.Fill(RTR);

                desconectar();

            }
            catch (SqlException ex)
            {
                desconectar();
                MessageBox.Show(ex.ToString());
            }

            return RTR;
        }

        protected DataTable R_repM2()
        {

            SqlDataAdapter cmd = new SqlDataAdapter(ProD9, _conexion);
            cmd.SelectCommand.CommandType = CommandType.StoredProcedure;

            cmd.SelectCommand.Parameters.Add("@idal", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@idPE", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@idca", SqlDbType.Char).Value = "";

            cmd.SelectCommand.Parameters.Add("@opc", SqlDbType.Char).Value = "prM2";
            try
            {


                cmd.Fill(RTR);

                desconectar();

            }
            catch (SqlException ex)
            {
                desconectar();
                MessageBox.Show(ex.ToString());
            }

            return RTR;
        }

        protected DataTable R_repM3()
        {

            SqlDataAdapter cmd = new SqlDataAdapter(ProD9, _conexion);
            cmd.SelectCommand.CommandType = CommandType.StoredProcedure;

            cmd.SelectCommand.Parameters.Add("@idal", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@idPE", SqlDbType.Char).Value = "";
            cmd.SelectCommand.Parameters.Add("@idca", SqlDbType.Char).Value = "";

            cmd.SelectCommand.Parameters.Add("@opc", SqlDbType.Char).Value = "prM3";
            try
            {


                cmd.Fill(RTR);

                desconectar();

            }
            catch (SqlException ex)
            {
                desconectar();
                MessageBox.Show(ex.ToString());
            }

            return RTR;
        }
    }
}


           