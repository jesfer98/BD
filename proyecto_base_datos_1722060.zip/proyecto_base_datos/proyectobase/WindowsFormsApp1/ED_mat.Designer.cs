﻿namespace WindowsFormsApp1
{
    partial class ED_mat
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.TB_N = new System.Windows.Forms.TextBox();
            this.TB_cl = new System.Windows.Forms.TextBox();
            this.num_cred = new System.Windows.Forms.NumericUpDown();
            this.num_HS = new System.Windows.Forms.NumericUpDown();
            this.CD_car = new System.Windows.Forms.ComboBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.bAc = new System.Windows.Forms.Button();
            this.bEd = new System.Windows.Forms.Button();
            this.bCl = new System.Windows.Forms.Button();
            this.numsem = new System.Windows.Forms.NumericUpDown();
            this.semestre = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.num_cred)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_HS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numsem)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(34, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(142, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "nombre de la materia";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(34, 254);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "descripcion";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(34, 67);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "clave";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(33, 104);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(58, 17);
            this.label4.TabIndex = 3;
            this.label4.Text = "creditos";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(33, 182);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(127, 17);
            this.label5.TabIndex = 4;
            this.label5.Text = "Horas a la semana";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(34, 227);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(58, 17);
            this.label6.TabIndex = 5;
            this.label6.Text = " carrera";
            // 
            // TB_N
            // 
            this.TB_N.Location = new System.Drawing.Point(197, 23);
            this.TB_N.Name = "TB_N";
            this.TB_N.Size = new System.Drawing.Size(257, 22);
            this.TB_N.TabIndex = 6;
            // 
            // TB_cl
            // 
            this.TB_cl.Location = new System.Drawing.Point(197, 62);
            this.TB_cl.Name = "TB_cl";
            this.TB_cl.Size = new System.Drawing.Size(257, 22);
            this.TB_cl.TabIndex = 7;
            // 
            // num_cred
            // 
            this.num_cred.Location = new System.Drawing.Point(196, 102);
            this.num_cred.Name = "num_cred";
            this.num_cred.Size = new System.Drawing.Size(120, 22);
            this.num_cred.TabIndex = 8;
            // 
            // num_HS
            // 
            this.num_HS.Location = new System.Drawing.Point(196, 180);
            this.num_HS.Name = "num_HS";
            this.num_HS.Size = new System.Drawing.Size(120, 22);
            this.num_HS.TabIndex = 9;
            // 
            // CD_car
            // 
            this.CD_car.FormattingEnabled = true;
            this.CD_car.Location = new System.Drawing.Point(196, 224);
            this.CD_car.Name = "CD_car";
            this.CD_car.Size = new System.Drawing.Size(258, 24);
            this.CD_car.TabIndex = 10;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(37, 274);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(417, 97);
            this.textBox1.TabIndex = 11;
            // 
            // bAc
            // 
            this.bAc.Location = new System.Drawing.Point(37, 392);
            this.bAc.Name = "bAc";
            this.bAc.Size = new System.Drawing.Size(108, 36);
            this.bAc.TabIndex = 12;
            this.bAc.Text = "aceptar";
            this.bAc.UseVisualStyleBackColor = true;
            this.bAc.Click += new System.EventHandler(this.bAc_Click);
            // 
            // bEd
            // 
            this.bEd.Location = new System.Drawing.Point(187, 392);
            this.bEd.Name = "bEd";
            this.bEd.Size = new System.Drawing.Size(108, 36);
            this.bEd.TabIndex = 13;
            this.bEd.Text = "editar";
            this.bEd.UseVisualStyleBackColor = true;
            this.bEd.Click += new System.EventHandler(this.bEd_Click);
            // 
            // bCl
            // 
            this.bCl.Location = new System.Drawing.Point(346, 392);
            this.bCl.Name = "bCl";
            this.bCl.Size = new System.Drawing.Size(108, 36);
            this.bCl.TabIndex = 14;
            this.bCl.Text = "cancelar";
            this.bCl.UseVisualStyleBackColor = true;
            this.bCl.Click += new System.EventHandler(this.bCl_Click);
            // 
            // numsem
            // 
            this.numsem.Location = new System.Drawing.Point(196, 142);
            this.numsem.Name = "numsem";
            this.numsem.Size = new System.Drawing.Size(120, 22);
            this.numsem.TabIndex = 16;
            // 
            // semestre
            // 
            this.semestre.AutoSize = true;
            this.semestre.Location = new System.Drawing.Point(33, 144);
            this.semestre.Name = "semestre";
            this.semestre.Size = new System.Drawing.Size(73, 17);
            this.semestre.TabIndex = 15;
            this.semestre.Text = "sesmestre";
            // 
            // ED_mat
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(492, 440);
            this.Controls.Add(this.numsem);
            this.Controls.Add(this.semestre);
            this.Controls.Add(this.bCl);
            this.Controls.Add(this.bEd);
            this.Controls.Add(this.bAc);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.CD_car);
            this.Controls.Add(this.num_HS);
            this.Controls.Add(this.num_cred);
            this.Controls.Add(this.TB_cl);
            this.Controls.Add(this.TB_N);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "ED_mat";
            this.Text = "ED_mat";
            this.Load += new System.EventHandler(this.ED_mat_Load);
            ((System.ComponentModel.ISupportInitialize)(this.num_cred)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_HS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numsem)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox TB_N;
        private System.Windows.Forms.TextBox TB_cl;
        private System.Windows.Forms.NumericUpDown num_cred;
        private System.Windows.Forms.NumericUpDown num_HS;
        private System.Windows.Forms.ComboBox CD_car;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button bAc;
        private System.Windows.Forms.Button bEd;
        private System.Windows.Forms.Button bCl;
        private System.Windows.Forms.NumericUpDown numsem;
        private System.Windows.Forms.Label semestre;
    }
}