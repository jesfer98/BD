﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class ED_mat : Form
    {

        private DataTable DT = new DataTable();
        public static string SetValueForText1 = "";
        public static Boolean Act = false;
        public static Boolean edt = false;
        private int Idref;
        private int typ;

        public ED_mat()
        {
            InitializeComponent();
            typ = 0;
        }
        public ED_mat(int carr)
        {
            InitializeComponent();
            typ = carr;
        }

        private void bCl_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void bAc_Click(object sender, EventArgs e)
        {
            action(0);
        }


        private void FilCB(int SeT)
        {
            DT.Rows.Clear();
            CD_car.DisplayMember = "";
            CD_car.ValueMember = "";

            CarDB cox = new CarDB();

            DT = cox.CBcar_A(SeT);

            CD_car.DataSource = DT;
            CD_car.DisplayMember = "nombre";
            CD_car.ValueMember = "id";
            CD_car.DataSource = DT;
            CD_car.SelectedIndex = -1;
        }

        private void ED_mat_Load(object sender, EventArgs e)
        {
            semestre.Visible = false;
            numsem.Visible = false;

            FilCB(typ);

            SetValueForText1 = materias.SeTV1;



            if (SetValueForText1 != "")
            {
                bAc.Enabled = false;
                bEd.Enabled = true;
                edt = true;
                //label6.Visible = true;
                modCar();
            }
            else
            {
                SetValueForText1 = "0";
                bAc.Enabled = true;
                bEd.Enabled = false;

                label6.Visible = true;
            }


        }


        private void modCar()
        {
            DataTable RT = new DataTable();
            RT.Rows.Clear();
            matDB cod = new matDB();
            RT = cod.regisH(Int32.Parse(SetValueForText1));

            if (RT.Rows.Count == 1)
                Idref= Int32.Parse(RT.Rows[0][0].ToString());

            TB_N.Text = RT.Rows[0][1].ToString();
            TB_cl.Text = RT.Rows[0][3].ToString();
            num_cred.Value = Int32.Parse(RT.Rows[0][4].ToString());
            num_HS.Value = Int32.Parse(RT.Rows[0][5].ToString());
            CD_car.SelectedValue = Int32.Parse(RT.Rows[0][6].ToString());

            textBox1.Text = RT.Rows[0][2].ToString();



        }

        private void bEd_Click(object sender, EventArgs e)
        {
            action(1);
        }

        private void action(int tip)
        {
            string nombre = TB_N.Text;
            string clave = TB_cl.Text;
            string desc = textBox1.Text;
            if(clave!=""&&desc != "" &&nombre != "" 
                && num_cred.Value.ToString()!=""&&
                num_HS.Value.ToString()!=""&& CD_car.SelectedValue.ToString()!="")
            { 
            int cred = Convert.ToInt32(num_cred.Value.ToString());
            int H_S = Convert.ToInt32(num_HS.Value.ToString());
            int carr = Convert.ToInt32(CD_car.SelectedValue.ToString());

            matDB con = new matDB();
            if (tip == 0)
                con.novoalumM(nombre, clave, cred, H_S, carr, desc);
            else if (tip == 1)
                con.modreg(Idref, nombre, clave, cred, H_S, carr, desc);

            this.Close();
        }
        }
    }

    
}
