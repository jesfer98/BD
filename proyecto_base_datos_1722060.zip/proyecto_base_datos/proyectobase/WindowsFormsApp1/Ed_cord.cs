﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class Ed_cord : Form
    {

        private DataTable DT = new DataTable();
        public static string SetValueForText1 = "";
        //static string constring = ConfigurationManager.ConnectionStrings["SQLConection"].ConnectionString;
        //SqlConnection con = new SqlConnection(constring);



       static int i ;


        public Ed_cord()
        {
            InitializeComponent();
        }

        private void Sg_Nom_TB_TextChanged(object sender, EventArgs e)
        {

        }

        private void Cancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void mod() {
            DataTable RT = new DataTable();
            DT.Rows.Clear();
            coordy cod = new coordy();
            RT = cod.reg(i);

            if (RT.Rows.Count == 1)


                 Pr_Nom_TB.Text = RT.Rows[0][0].ToString();
                 Sg_Nom_TB.Text = RT.Rows[0][1].ToString();
                 Ap_Pat_TB.Text = RT.Rows[0][2].ToString();
                 Ap_Mat_TB.Text = RT.Rows[0][3].ToString();
                 textBox1.Text = RT.Rows[0][4].ToString();
                 textBox2.Text = RT.Rows[0][5].ToString();
                 textBox3.Text = RT.Rows[0][6].ToString();
         

                 dateTimePicker1.Value = Convert.ToDateTime(RT.Rows[0][7].ToString());
                 textBox4.Text = RT.Rows[0][8].ToString();

    



        }

        private void agregar_Click(object sender, EventArgs e)
        {
            AgreF();
            this.Close();
        }

        private void AgreF()
        {
        string Pr=    Pr_Nom_TB.Text;
        string Sg=   Sg_Nom_TB.Text;
        string AP=   Ap_Pat_TB.Text;
        string AM=   Ap_Mat_TB.Text;
        string CL=   textBox1.Text;
        string Pass=   textBox2.Text;
        string Nom=   textBox3.Text;
        DateTime nac=   dateTimePicker1.Value;
        string TU = textBox4.Text;

            if (Pr != "" && Sg != "" && AP != "" && AM != "" 
                && CL != "" && Pass != "" && Nom != "" && TU != "")
            {
                coordy cod = new coordy();
                cod.cornew(Pr, Sg, AP, AM, nac, CL, Pass, Nom, TU);

            }
            else MessageBox.Show("favor de llenar todos los datos");


        }

        private void Ed_cord_Load(object sender, EventArgs e)
        {
          



            SetValueForText1 = coordinadores.SetValueForText1;

            if (SetValueForText1 != "")
            {
                agregar.Enabled = false;
                editar.Enabled = true;
              
                textBox3.ReadOnly = true;
                i = Convert.ToInt32(SetValueForText1);
                mod();
            }
            else {

                agregar.Enabled = true;
                editar.Enabled = false;
            }
        }

        private void modF()
        {
            string Pr = Pr_Nom_TB.Text;
            string Sg = Sg_Nom_TB.Text;
            string AP = Ap_Pat_TB.Text;
            string AM = Ap_Mat_TB.Text;
            string CL = textBox1.Text;
            string Pass = textBox2.Text;
            string Nom = textBox3.Text;
            DateTime nac = dateTimePicker1.Value;
            string TU = textBox4.Text;

            if (Pr != "" && Sg != "" && AP != "" && AM != ""
              && CL != "" && Pass != "" && Nom != "" && TU != "")
            {
                coordy cod = new coordy();
                cod.modyF(i, Pr, Sg, AP, AM, nac, CL, Pass, Nom, TU);
            }
            else MessageBox.Show("favor de llenar todos los datos");
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void editar_Click(object sender, EventArgs e)
        {
            modF();
            this.Close();
        }

        private void Pr_Nom_TB_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
