﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        DataTable DT = new DataTable();
        public static string SetValueForText1 = "";
        public Form1()
        {
            InitializeComponent();
            button1.Enabled = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            checar();
        }

        private void checar() {
            string C = textBox1.Text;
            string P = textBox2.Text;
            string T = Tipo.SelectedItem.ToString();
            int id;

            llave key = new llave();
          DT= llave.passa(C, P, T);

            if (T == "administrador")
            {

                if (DT.Rows.Count > 0)
                {
                    SetValueForText1 = Tipo.SelectedItem.ToString();
                    //  MessageBox.Show(SetValueForText1);
                    inicio m = new inicio(SetValueForText1);
                    m.ShowDialog();
                }
                else
                {
                    MessageBox.Show("no hay");
                }

                DT.Clear();
            }
            else if (T == "coordinador")
            {

                if (DT.Rows.Count > 0)
                {
                    SetValueForText1 = Tipo.SelectedItem.ToString();
                    id = Int32.Parse(DT.Rows[0][0].ToString());
                    incoord vent = new incoord(SetValueForText1,id);
                    vent.ShowDialog();
                }
                else
                {
                    MessageBox.Show("no hay");
                }

                DT.Clear();


            }
        }

    

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            button1.Enabled = true;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
