﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    class TAC:ConDB
    {

        private DataTable RTT = new DataTable();
        private DataTable DTT1 = new DataTable();
        private DataTable DTT2 = new DataTable();
        private DataTable DTT3 = new DataTable();




      

        public DataTable list1(int Typ)
        {
  
            RTT = T_list1(Typ);
            return RTT;
        }

        public DataTable list2(int Typ,int sem)
        {
            
            RTT = T_list2(Typ, sem);

            return RTT;
        }

        public DataTable list3(int Typ, int sem)
        {
           
            RTT = T_list3(Typ, sem);
            return RTT;
        }

        public DataTable comp(int ida,int idg)
        {
           

            DTT1 = T_comp(ida,idg);

            return DTT1;
        }

        public DataTable max(int idg)
        {
            
            DTT2 = T_max(idg);
            return DTT2;
        }

        public DataTable total(int ida)
        {
            
            DTT3 = T_total(ida);
            return DTT3;
        }

        public void regist(int ida, int sem, int idC) {

            
            T_regist(ida, sem, idC);


        }

        public void borra(int ida, int idC)
        {
            
            T_borra(ida,idC);
            
        }

        public void final()
        {
                T_final();

            }

        public DataTable pase(int ida, int idM) {
           
            RTT = T_pase(ida, idM);

            return RTT;
        }

        public DataTable regm(int idg)
        {
            
            DTT2 = T_regm(idg);

            return DTT2;
        }

        public void modcal( int sem, int idC)
        {
       T_modcal(sem, idC);


        }

        public DataTable cre(int ida,int sem)
        {
            DataTable crt = new DataTable();

            crt = T_cred(ida,sem);

            return crt;
        }


        public DataTable PE( int sem)
        {
            DataTable crt = new DataTable();

            crt = T_sem(sem);

            return crt;
        }

        public DataTable crM(int idg)
        {
           
            DataTable crt = new DataTable();
            crt = T_cM(idg);

            return crt;
        }

        public DataTable chefin(int idg)
        {

            DataTable crt = new DataTable();
            crt = T_chefin(idg);

            return crt;
        }

    }
}
