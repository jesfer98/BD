﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;


namespace WindowsFormsApp1
{
    class alumnDB : ConDB
    {
        
        DataTable RTAL = new DataTable();
        public alumnDB()
        {
           
        }

   

       
        //ya
        public DataTable listalumn(int Typ,int ca)
        {

            RTAL = AL_listalumn(Typ,ca);

            return RTAL;
        }

        public void novoalum(string Pr, string Sg, string AP, string AM,
            DateTime Nac, string cl, string ubi, string mat, int car)
        {

            AL_novoalum(Pr,  Sg, AP,  AM,Nac,cl,  ubi, mat,  car);

        }

        public DataTable reg(int Tid) {

          
            RTAL = AL_reg(Tid);
            return RTAL;


        }



        public void modyF(int id,string Pr, string Sg, string AP, string AM,
            DateTime Nac, string cl, string ubi, string mat, int car)
        {

           
         
          AL_modyF(id,Pr, Sg, AP, AM,
             Nac, cl, ubi, mat, car);

        }


        public void baja(int id)
        {

            AL_baja(id);
        }
    }
}
