﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class alumnos : Form
    {
        private DataTable DT = new DataTable();
        public static string SeTV1 = "";
        private static string usu;
        private string PerEsc;
        private int typ, car;
        public static Boolean Act = false;
        public static int TAC;

        public alumnos()
        {
            InitializeComponent();
            usu = Form1.SetValueForText1;
            car = 0;
            PerEsc = inicio.VAL;
        }
        public alumnos(string a, int b,string pre)
        {
            InitializeComponent();
            usu = a;
            car = b;
            PerEsc = pre;
        }

        private void alumnos_Load(object sender, EventArgs e)
        {
            actualizarT();
         
        }

        private void actualizarT()
        {

            DT.Rows.Clear();
            dataGridView1.Refresh();
            dataGridView1.ReadOnly = true;
            dataGridView1.DataSource = DT;
           


            if (usu == "administrador")
            {
                typ = 1;
                car = 0;
            }
            else if (usu == "coordinador")
            {
                typ = 3;
                
            }
            else {
                typ = 0;
                car = 0;
            }

            alumnDB tab = new alumnDB();

            DT = tab.listalumn(typ,car);

            if (DT.Rows.Count > 0)
            {
                DataView DV = new DataView(DT);

                

                dataGridView1.ReadOnly = true;
                dataGridView1.DataSource = DV;
                dataGridView1.AutoResizeColumns();
                dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            }
            else
            {
                MessageBox.Show("no hay alumnos inscritos");
            }

            Act = true;

            if (inicio.VAL == "1") {
                agregar_alu.Enabled = true;
            }
        }

        private void alumnos_Activated(object sender, EventArgs e)
        {
            if (Act == false)
            {
                SeTV1 = "";
                actualizarT();
            }
        }

        private void agregar_alu_Click(object sender, EventArgs e)
        {
            OPAED("",car);
        }

        private void salir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void OPAED(string SE,int car) {
            TAC = car;

            editAlu EDa = new editAlu(SE,typ,PerEsc,car);
            EDa.ShowDialog();

            Act = false;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
    
        }

        private void select(DataGridViewCellEventArgs e) {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow select = this.dataGridView1.Rows[e.RowIndex];
                //  SetValueForText1 = this.dataGridView1[e.ColumnIndex, e.RowIndex].Value.ToString();
            }
            //label1.Text=SetValueForText1;
            if (Convert.ToString(dataGridView1.CurrentRow.Cells[0].Value) != "")
            {
                int index = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value);
                //  MessageBox.Show(index.ToString());



                if (dataGridView1.SelectedCells.Count >= 0)
                {
                    int selectedrowindex = dataGridView1.SelectedCells[0].RowIndex;

                    DataGridViewRow selectedRow = dataGridView1.Rows[selectedrowindex];

                    string a = Convert.ToString(selectedRow.Cells["id"].Value);

                    SeTV1 = a;

                    OPAED(a,car);

                }
            }
        }

        private void BON_Click(object sender, EventArgs e)
        {
            DataView DV = new DataView(DT);

            DV.Sort = "nombre del alumno";

            dataGridView1.ReadOnly = true;
            dataGridView1.DataSource = DV;
            dataGridView1.AutoResizeColumns();
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DataView DV = new DataView(DT);
            DV.Sort = "carrera";

            dataGridView1.ReadOnly = true;
            dataGridView1.DataSource = DV;
            dataGridView1.AutoResizeColumns();
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DataView DV = new DataView(DT);
            DV.Sort = "promedio";

            dataGridView1.ReadOnly = true;
            dataGridView1.DataSource = DV;
            dataGridView1.AutoResizeColumns();
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            select(e);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DataView DV = new DataView(DT);
            DV.Sort = "creditos";

            dataGridView1.ReadOnly = true;
            dataGridView1.DataSource = DV;
            dataGridView1.AutoResizeColumns();
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        public int getTyp() {
            return typ;
        }
    }
}
