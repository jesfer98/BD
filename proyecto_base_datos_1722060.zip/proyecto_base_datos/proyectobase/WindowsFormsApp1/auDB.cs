﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    class auDB:ConDB
    {
        DataTable RTAU = new DataTable();
   
        

        public auDB() {

        
        }

        public DataTable list() {
            
            RTAU = AU_list();
            return RTAU;


        }

        public DataTable che(int num)
        {
        
            RTAU = AU_che(num);
            return RTAU;


        }

        public DataTable regisA(int id)
        {
            
        
            RTAU =AU_regis(id);
            return RTAU;



        }

        public void agreg(int num,int cant) {
         AU_agreg(num,cant);

        }

        public void mod(int id, int num, int cant)
        {
           
            AU_mod(id, num, cant);

        }
    }
}
