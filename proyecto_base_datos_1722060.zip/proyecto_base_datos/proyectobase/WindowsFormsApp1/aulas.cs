﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class aulas : Form
    {
        private DataTable DT = new DataTable();
        public static string SetValueForText1 = "";
        public static Boolean Act = false;

        public aulas()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void aulas_Load(object sender, EventArgs e)
        {
            acuta();
            Act = true;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }

        private void select(DataGridViewCellEventArgs e) {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow select = this.dataGridView1.Rows[e.RowIndex];
                //  SetValueForText1 = this.dataGridView1[e.ColumnIndex, e.RowIndex].Value.ToString();
            }
            //label1.Text=SetValueForText1;

            if (Convert.ToString(dataGridView1.CurrentRow.Cells[0].Value) != "")
            {
                int index = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value);
              //  MessageBox.Show(index.ToString());



                if (dataGridView1.SelectedCells.Count >= 0)
                {
                    int selectedrowindex = dataGridView1.SelectedCells[0].RowIndex;

                    DataGridViewRow selectedRow = dataGridView1.Rows[selectedrowindex];

                    string a = Convert.ToString(selectedRow.Cells["id"].Value);

                    SetValueForText1 = a;

                    OP_ed();

                }
            }
        }


        private void OP_ed()
        {
            edAula AL = new edAula();
            AL.ShowDialog();
            Act = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OP_ed();
           
        }


        private void acuta() {
            DT.Rows.Clear();
            dataGridView1.Refresh();
            dataGridView1.ReadOnly = true;
            dataGridView1.DataSource = DT;



            auDB aul = new auDB();
           DT=aul.list();

            if (DT.Rows.Count > 0)
            {

                dataGridView1.ReadOnly = true;
                dataGridView1.DataSource = DT;
                dataGridView1.AutoResizeColumns();
                dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            }
            else
            {
                MessageBox.Show("no hay aulas registrados");
            }

            Act = true;
        }

        private void aulas_Activated(object sender, EventArgs e)
        {
            if (Act == false)
            {
                acuta();
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            select(e);
        }
    }
}
