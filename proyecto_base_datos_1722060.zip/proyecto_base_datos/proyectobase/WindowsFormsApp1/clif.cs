﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class clif : Form
    {
        DataTable DT = new DataTable();
        DataTable DT2 = new DataTable();
        DataTable CT = new DataTable();
        DataTable MT = new DataTable();
        DataTable GR = new DataTable();
        private static Boolean ACTIVO = true;
        private int typ, car;
        private int c_A;
        private int IDPE;
        public clif()
        {
            InitializeComponent();
            c_A = 0;
        }

        public clif(int a,int SE)
        {
            InitializeComponent();
            c_A=a;
            IDPE = SE;
        }

        private void clif_Load(object sender, EventArgs e)
        {
            FilCB(c_A);
        }

        private void FilCB(int SeT)
        {
            CT.Rows.Clear();
            CB_car.DisplayMember = "";
            CB_car.ValueMember = "";

            CarDB cox = new CarDB();

            CT = cox.CBcar_A(SeT);

            CB_car.DataSource = CT;
            CB_car.DisplayMember = "nombre";
            CB_car.ValueMember = "id";
            CB_car.DataSource = CT;
            CB_car.SelectedIndex = -1;
        }

        private void CB_car_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (CB_car.Text != "")
            {
                //MessageBox.Show(CB_car.SelectedValue.ToString());
                FilMB();
            }
        }

        private void FilMB()
        {
            CB_mat.DisplayMember = "";
            CB_mat.ValueMember = "";
            int T;
            matDB cox = new matDB();

            string P = CB_car.Text;
            MT = cox.lista2();

            DataView MV = new DataView(MT);
            if (P != "" && P != "System.Data.DataRowView" && CB_car.SelectedValue.ToString() != "System.Data.DataRowView")
            {

                T = Convert.ToInt32(CB_car.SelectedValue.ToString());
            }
            else { T = 0; }

            MV.RowFilter = "carrera =" + "'" + T + "'";

            CB_mat.DataSource = MV;
            CB_mat.DisplayMember = "nombre";
            CB_mat.ValueMember = "id";
            CB_mat.DataSource = MV;
            CB_mat.SelectedIndex = -1;
        }

        private void compro()
        {
            string P = CB_mat.Text;

            if (P != "" && P != "System.Data.DataRowView" && CB_mat.SelectedValue.ToString() != "System.Data.DataRowView")
            {
                //  MessageBox.Show(CB_GR.SelectedValue.ToString());


                actTABLE2();

                ACTIVO = true;
            }
        }

        private void CB_mat_SelectedIndexChanged(object sender, EventArgs e)
        {
            compro();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow select = this.dataGridView1.Rows[e.RowIndex];
                //  SetValueForText1 = this.dataGridView1[e.ColumnIndex, e.RowIndex].Value.ToString();
            }
            if (Convert.ToString(dataGridView1.CurrentRow.Cells[0].Value) != "")
            {
                int index = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value);

                if (dataGridView1.SelectedCells.Count >= 0)
                {
                    int selectedrowindex = dataGridView1.SelectedCells[0].RowIndex;

                    DataGridViewRow selectedRow = dataGridView1.Rows[selectedrowindex];

                    string a = Convert.ToString(selectedRow.Cells["id"].Value);


                    MessageBox.Show(a);
                    //SetValueForText1 = a;

                    OP_ed(a);

                }
            }
        }

        private void OP_ed(string a)
        {
            int n = Convert.ToInt32(a);
            putcalif call = new putcalif(n);
            call.ShowDialog();
            ACTIVO = false;
        }

        private void clif_MouseEnter(object sender, EventArgs e)
        {
            if (ACTIVO == false)
            { compro(); }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void actTABLE2()
        {
            DT2.Rows.Clear();

            dataGridView1.Refresh();
            dataGridView1.ReadOnly = true;
            dataGridView1.DataSource = DT2;

            TAC tab = new TAC();

            string P = CB_mat.Text;

            if (P != "" && P != "System.Data.DataRowView" && CB_mat.SelectedValue.ToString() != "System.Data.DataRowView")
            {

                car = Convert.ToInt32(CB_mat.SelectedValue.ToString());
            }


            DT2 = tab.list3(car,IDPE);

            if (DT2.Rows.Count > 0)
            {
                DataView DV2 = new DataView(DT2);


              
                dataGridView1.Columns.Clear();
                dataGridView1.ReadOnly = false;
                dataGridView1.DataSource = DV2;



                dataGridView1.AutoResizeColumns();
               

                dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            }
            else
            {
                MessageBox.Show("no hay alumnos inscritos");
            }

        }
    }
}