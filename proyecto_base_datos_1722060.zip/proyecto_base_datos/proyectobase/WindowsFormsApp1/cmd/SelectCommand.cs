﻿namespace cmd
{
    internal class SelectCommand
    {
        internal class CommandType
        {
        }
    }
}