﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class coordinadores : Form
    {

        private DataTable DT = new DataTable();
        public static string SetValueForText1 = "";
        //static string constring = ConfigurationManager.ConnectionStrings["SQLConection"].ConnectionString;
        //SqlConnection con = new SqlConnection(constring);
        public  static Boolean Act = false;
       

        public coordinadores()
        {
            InitializeComponent();
        }

        private void salir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void agregar_coo_Click(object sender, EventArgs e)
        {
            SetValueForText1 = "";
            OP_ed();
        }

        private void coordinadores_Load(object sender, EventArgs e)
        {
            actualiza_DGV();
            Act = true;
          //  timer1.Enabled = true;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {


            if (e.RowIndex >= 0)
            {
                DataGridViewRow select = this.dataGridView1.Rows[e.RowIndex];
                //  SetValueForText1 = this.dataGridView1[e.ColumnIndex, e.RowIndex].Value.ToString();
            }

            if (Convert.ToString(dataGridView1.CurrentRow.Cells[0].Value) != "")
            { 
            int index = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value);

            if (dataGridView1.SelectedCells.Count >= 0)
            {
                int selectedrowindex = dataGridView1.SelectedCells[0].RowIndex;

                DataGridViewRow selectedRow = dataGridView1.Rows[selectedrowindex];

                string a = Convert.ToString(selectedRow.Cells["id"].Value);

                SetValueForText1 = a;

                OP_ed();

            }
        }
        }



        public void actualiza_DGV() {

            DT.Rows.Clear();
            dataGridView1.Refresh();
            dataGridView1.ReadOnly = true;
            dataGridView1.DataSource = DT;

            ACTDT actual = new ACTDT();

            DT = actual.listcord();

            if (DT.Rows.Count > 0)
            {

                dataGridView1.ReadOnly = true;
                dataGridView1.DataSource = DT;
                dataGridView1.AutoResizeColumns();
                dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            }
            else
            {
                MessageBox.Show("no hay coordinadores registrados");
            }


        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            actualiza_DGV();
        }

        private void OP_ed() {

            Ed_cord v2 = new Ed_cord();
            v2.ShowDialog();
            Act = false;
        }

        private void coordinadores_Activated(object sender, EventArgs e)
        {
            if (Act == false)
            {
                actualiza_DGV();
                Act = true;
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
