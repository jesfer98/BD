﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;
using System.Data;
using System.Threading.Tasks;

using System.Configuration;
using System.Data.SqlClient;


namespace WindowsFormsApp1
{
   public class coordy : ConDB
    {

        public static void agregar(string Pr, string Sg, string AP, string AM,
            DateTime Nac, string cl, string pas, string nom, string TU)
        {
            DataTable RT = new DataTable();
            ConDB conexion = new ConDB();

            conexion.cornew(Pr, Sg, AP, AM, Nac, cl, pas, nom, TU);


        }

        public  DataTable reg(int id)
        {
            DataTable RT = new DataTable();
            ConDB conexion = new ConDB();

            RT = conexion.regis(id);

            return RT;
        }

        public static void mody(int i, string Pr, string Sg, string AP, string AM,
            DateTime Nac, string cl, string pas, string nom, string TU) {

            ConDB conexion = new ConDB();
            conexion.modyF( i,  Pr,  Sg,  AP,  AM, Nac,  cl,  pas, nom,  TU);

        }


    }
}
