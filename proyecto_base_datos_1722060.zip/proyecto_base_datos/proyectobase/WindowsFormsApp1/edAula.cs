﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class edAula : Form
    {
        private DataTable DT = new DataTable();
        public static string SetValueForText1 = "";
        public static Boolean Act = false;
        public static Boolean edt = false;
        private int Idref;
        private int aunum;

        public edAula()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        { DataTable DT = new DataTable();
            int ANUM;
            int numau;
            auDB AL = new auDB();


            DT = AL.che(Convert.ToInt32(numN.Value.ToString()));
            ANUM = DT.Rows.Count;
            if (ANUM <1)
            {
                AL.agreg(Convert.ToInt32(numN.Value.ToString()), Convert.ToInt32(numC.Value.ToString()));
                this.Close();
            }
            else {
                MessageBox.Show("numero de aula ya registrado");
            }

           
        }

        private void edAula_Load(object sender, EventArgs e)
        {
            SetValueForText1 = aulas.SetValueForText1;

            if (SetValueForText1 != "")
            {
                button1.Enabled = false;
                button2.Enabled = true;
                edt = false;
                //label6.Visible = true;
                modcar();
            }
            else
            {
                SetValueForText1 = "0";
                button1.Enabled = true;
                button2.Enabled = false;

               // label6.Visible = true;
            }
        }

        private void modcar() {
            DataTable RT = new DataTable();
            RT.Rows.Clear();
            auDB AL = new auDB();
            RT = AL.regisA(Int32.Parse(SetValueForText1));

            if (RT.Rows.Count == 1)
            {
                Idref = Int32.Parse(RT.Rows[0][0].ToString());

                aunum=Int32.Parse(RT.Rows[0][1].ToString());
                numN.Value = aunum;
                numC.Value = Int32.Parse(RT.Rows[0][2].ToString());
            }
            }

        private void button2_Click(object sender, EventArgs e)
        {
           

            auDB AL = new auDB();

            DataTable DT = new DataTable();
            int ANUM;
            int NN= Convert.ToInt32(numN.Value.ToString());
            DT = AL.che(NN);
            ANUM = DT.Rows.Count;
         
            if (ANUM < 1 || NN == aunum)
            {
                AL.mod(Int32.Parse(SetValueForText1), Convert.ToInt32(numN.Value.ToString()), Convert.ToInt32(numC.Value.ToString()));
                this.Close();
            }
            else
            {
                MessageBox.Show("numero de aula ya registrado");
            }


            
        }

        private void numN_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
