﻿namespace WindowsFormsApp1
{
    partial class editAlu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label9 = new System.Windows.Forms.Label();
            this.LugN = new System.Windows.Forms.TextBox();
            this.Cancelar = new System.Windows.Forms.Button();
            this.editar = new System.Windows.Forms.Button();
            this.agregar = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.matricula = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.Ap_Mat_TB = new System.Windows.Forms.TextBox();
            this.Ap_Pat_TB = new System.Windows.Forms.TextBox();
            this.Sg_Nom_TB = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Pr_Nom_TB = new System.Windows.Forms.TextBox();
            this.CB_car = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.CB_gen = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.CB_sem = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.crearK = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(45, 99);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(132, 17);
            this.label9.TabIndex = 44;
            this.label9.Text = "lugar de nacimiento";
            // 
            // LugN
            // 
            this.LugN.Location = new System.Drawing.Point(194, 99);
            this.LugN.Name = "LugN";
            this.LugN.Size = new System.Drawing.Size(536, 22);
            this.LugN.TabIndex = 43;
            // 
            // Cancelar
            // 
            this.Cancelar.Location = new System.Drawing.Point(626, 198);
            this.Cancelar.Name = "Cancelar";
            this.Cancelar.Size = new System.Drawing.Size(104, 32);
            this.Cancelar.TabIndex = 42;
            this.Cancelar.Text = "Cancelar";
            this.Cancelar.UseVisualStyleBackColor = true;
            this.Cancelar.Click += new System.EventHandler(this.Cancelar_Click);
            // 
            // editar
            // 
            this.editar.Location = new System.Drawing.Point(194, 198);
            this.editar.Name = "editar";
            this.editar.Size = new System.Drawing.Size(104, 32);
            this.editar.TabIndex = 41;
            this.editar.Text = "Editar";
            this.editar.UseVisualStyleBackColor = true;
            this.editar.Click += new System.EventHandler(this.editar_Click);
            // 
            // agregar
            // 
            this.agregar.Location = new System.Drawing.Point(48, 198);
            this.agregar.Name = "agregar";
            this.agregar.Size = new System.Drawing.Size(104, 32);
            this.agregar.TabIndex = 40;
            this.agregar.Text = "Agregar";
            this.agregar.UseVisualStyleBackColor = true;
            this.agregar.Click += new System.EventHandler(this.agregar_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(324, 74);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(141, 17);
            this.label7.TabIndex = 37;
            this.label7.Text = "Fecha de Nacimiento";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(471, 71);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(259, 22);
            this.dateTimePicker1.TabIndex = 36;
            // 
            // matricula
            // 
            this.matricula.Location = new System.Drawing.Point(116, 68);
            this.matricula.Name = "matricula";
            this.matricula.Size = new System.Drawing.Size(182, 22);
            this.matricula.TabIndex = 34;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(45, 71);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 17);
            this.label5.TabIndex = 32;
            this.label5.Text = "matricula";
            // 
            // Ap_Mat_TB
            // 
            this.Ap_Mat_TB.Location = new System.Drawing.Point(564, 43);
            this.Ap_Mat_TB.Name = "Ap_Mat_TB";
            this.Ap_Mat_TB.Size = new System.Drawing.Size(166, 22);
            this.Ap_Mat_TB.TabIndex = 31;
            // 
            // Ap_Pat_TB
            // 
            this.Ap_Pat_TB.Location = new System.Drawing.Point(392, 43);
            this.Ap_Pat_TB.Name = "Ap_Pat_TB";
            this.Ap_Pat_TB.Size = new System.Drawing.Size(166, 22);
            this.Ap_Pat_TB.TabIndex = 30;
            // 
            // Sg_Nom_TB
            // 
            this.Sg_Nom_TB.Location = new System.Drawing.Point(220, 43);
            this.Sg_Nom_TB.Name = "Sg_Nom_TB";
            this.Sg_Nom_TB.Size = new System.Drawing.Size(166, 22);
            this.Sg_Nom_TB.TabIndex = 29;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(586, 23);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(114, 17);
            this.label4.TabIndex = 28;
            this.label4.Text = "Apellido Materno";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(245, 23);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(119, 17);
            this.label3.TabIndex = 27;
            this.label3.Text = "Segundo Nombre";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(422, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(112, 17);
            this.label2.TabIndex = 26;
            this.label2.Text = "Apellido Paterno";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(68, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(103, 17);
            this.label1.TabIndex = 25;
            this.label1.Text = "Primer Nombre";
            // 
            // Pr_Nom_TB
            // 
            this.Pr_Nom_TB.Location = new System.Drawing.Point(48, 43);
            this.Pr_Nom_TB.Name = "Pr_Nom_TB";
            this.Pr_Nom_TB.Size = new System.Drawing.Size(166, 22);
            this.Pr_Nom_TB.TabIndex = 24;
            // 
            // CB_car
            // 
            this.CB_car.FormattingEnabled = true;
            this.CB_car.Location = new System.Drawing.Point(327, 157);
            this.CB_car.Name = "CB_car";
            this.CB_car.Size = new System.Drawing.Size(403, 24);
            this.CB_car.TabIndex = 45;
            this.CB_car.SelectedIndexChanged += new System.EventHandler(this.CB_car_SelectedIndexChanged);
            this.CB_car.TextUpdate += new System.EventHandler(this.CB_car_TextUpdate);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(45, 160);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(54, 17);
            this.label6.TabIndex = 46;
            this.label6.Text = "carrera";
            // 
            // CB_gen
            // 
            this.CB_gen.FormattingEnabled = true;
            this.CB_gen.Items.AddRange(new object[] {
            "femenino",
            "masculino",
            "otro"});
            this.CB_gen.Location = new System.Drawing.Point(194, 127);
            this.CB_gen.Name = "CB_gen";
            this.CB_gen.Size = new System.Drawing.Size(536, 24);
            this.CB_gen.TabIndex = 47;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(46, 130);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 17);
            this.label8.TabIndex = 48;
            this.label8.Text = "genero";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(347, 198);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(104, 32);
            this.button1.TabIndex = 49;
            this.button1.Text = "baja";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(49, 277);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(682, 234);
            this.dataGridView1.TabIndex = 50;
            // 
            // CB_sem
            // 
            this.CB_sem.FormattingEnabled = true;
            this.CB_sem.Location = new System.Drawing.Point(265, 247);
            this.CB_sem.Name = "CB_sem";
            this.CB_sem.Size = new System.Drawing.Size(465, 24);
            this.CB_sem.TabIndex = 51;
            this.CB_sem.SelectedIndexChanged += new System.EventHandler(this.CB_sem_SelectedIndexChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(123, 250);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(106, 17);
            this.label10.TabIndex = 52;
            this.label10.Text = "periodo escolar";
            // 
            // crearK
            // 
            this.crearK.Location = new System.Drawing.Point(265, 523);
            this.crearK.Name = "crearK";
            this.crearK.Size = new System.Drawing.Size(236, 32);
            this.crearK.TabIndex = 53;
            this.crearK.Text = "imprimir kardex";
            this.crearK.UseVisualStyleBackColor = true;
            this.crearK.Click += new System.EventHandler(this.crearK_Click);
            // 
            // editAlu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 567);
            this.Controls.Add(this.crearK);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.CB_sem);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.CB_gen);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.CB_car);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.LugN);
            this.Controls.Add(this.Cancelar);
            this.Controls.Add(this.editar);
            this.Controls.Add(this.agregar);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.matricula);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.Ap_Mat_TB);
            this.Controls.Add(this.Ap_Pat_TB);
            this.Controls.Add(this.Sg_Nom_TB);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Pr_Nom_TB);
            this.Name = "editAlu";
            this.Text = "editAlu";
            this.Load += new System.EventHandler(this.editAlu_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox LugN;
        private System.Windows.Forms.Button Cancelar;
        private System.Windows.Forms.Button editar;
        private System.Windows.Forms.Button agregar;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.TextBox matricula;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox Ap_Mat_TB;
        private System.Windows.Forms.TextBox Ap_Pat_TB;
        private System.Windows.Forms.TextBox Sg_Nom_TB;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox Pr_Nom_TB;
        private System.Windows.Forms.ComboBox CB_car;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox CB_gen;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.ComboBox CB_sem;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button crearK;
    }
}