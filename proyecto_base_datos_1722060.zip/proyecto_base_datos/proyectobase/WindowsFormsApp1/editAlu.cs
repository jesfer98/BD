﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;

using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class editAlu : Form
    {
        private DataTable DT = new DataTable();
         private DataTable RT = new DataTable();
        private static string SetValueForText1 = "";
        public static Boolean Act = false;
        public static Boolean edt = false;
        private int type, care;
        private static string val = "";
        public static Boolean cambio=false;

        public editAlu()
        {
            InitializeComponent();
        }
        public editAlu(string S,int TY,string pre,int car)
        {
            InitializeComponent();

            SetValueForText1 = S;
       
            type = TY;

            val = pre;
            care = car;
        }

        private void agregar_Click(object sender, EventArgs e)
        {
            newalum();
           

        }

        private void FilCB(int SeT)
        { 
            DataTable DT2 = new DataTable();
            DT2.Rows.Clear();
            CB_car.DisplayMember = "";
            CB_car.ValueMember = "";

            CarDB cox = new CarDB();

            DT2 = cox.CBcar_A(SeT);

           CB_car.DataSource = DT2;
           CB_car.DisplayMember = "nombre";
           CB_car.ValueMember = "id";
           CB_car.DataSource = DT2;
            CB_car.SelectedIndex = -1;
        }

        private void FilCB2()
        {
            DataTable DT2 = new DataTable();
            DT2.Rows.Clear();
            CB_sem.DisplayMember = "";
            CB_sem.ValueMember = "";

            semDB cox = new semDB();

            DT2 = cox.semCB();

            CB_sem.DataSource = DT2;
            CB_sem.DisplayMember = "descripcion";
            CB_sem.ValueMember = "id";
            CB_sem.DataSource = DT2;
            CB_sem.SelectedIndex = -1;
        }

        private void newalum()
        {
            string Pr = Pr_Nom_TB.Text;
            string Sg = Sg_Nom_TB.Text;
            string AP = Ap_Pat_TB.Text;
            string AM = Ap_Mat_TB.Text;
            string mat = matricula.Text;
            string Nlug = LugN.Text;
            string gen = CB_gen.SelectedItem.ToString();
            int car= Int32.Parse(CB_car.SelectedValue.ToString());
            DateTime nac = dateTimePicker1.Value;

            if (Pr != "" && Sg != "" && AP != "" && AM != "" && mat != "" && Nlug != "" && gen != "")
            {
                if (CB_car.SelectedValue.ToString() != "" || CB_car.SelectedValue.ToString() != null)
                {
                    alumnDB regis = new alumnDB();

                    regis.novoalum(Pr, Sg, AP, AM, nac, gen, Nlug, mat, car);
                    this.Close();
                }
            }
            else MessageBox.Show("favor de introducir todos los datos");

        }

        private void editAlu_Load(object sender, EventArgs e)
        {
            CB_sem.Enabled = false;
            crearK.Enabled = false;
           
            //   FilCB(type);



            if (val == "1" || val == "4")
            {
                agregar.Enabled = true;
                editar.Enabled = true;
                button1.Enabled = true;
            }
            else
            {
                agregar.Enabled = false;
                editar.Enabled = false;
                button1.Enabled = false;
            }



            if (SetValueForText1 != "" && type > 1)
            {

                FilCB(Int32.Parse(SetValueForText1));
                agregar.Enabled = false;

                edt = true;
                label6.Visible = true;
                modCar();
            }
            else if (SetValueForText1 != "" && type < 2)
            {
                FilCB(0);
                agregar.Enabled = false;
                edt = true;
                label6.Visible = true;
                modCar();
            }
            else if (SetValueForText1 == "" && type < 2)
            {
                dataGridView1.Visible = false;
                label10.Visible = false;
                CB_sem.Visible = false;
                crearK.Visible = false;
                this.Size = new Size(600, 229);
                SetValueForText1 = "0";
                editar.Enabled = false;
                button1.Enabled = false;
                FilCB(Int32.Parse(SetValueForText1));

                label6.Visible = true;
            }
            else
            {

                editar.Enabled = false;
                button1.Enabled = false;
                FilCB(care);

                label6.Visible = true;
            }
       



            Act = true;
        }

    


             private void llenarK() {


                DT.Rows.Clear();
                dataGridView1.Refresh();
                dataGridView1.ReadOnly = true;
                dataGridView1.DataSource = DT;





                repp tab = new repp();
            DT = tab.kar(Int32.Parse(SetValueForText1));

            
                if (DT.Rows.Count > 0)
                {
                    DataView DV = new DataView(DT);



                    dataGridView1.ReadOnly = true;
                    dataGridView1.DataSource = DV;
                    dataGridView1.AutoResizeColumns();
                    dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                }
                else
                {
                    MessageBox.Show("alumno sin materias inscritas");
                }

    
        }


        private void modCar()
        {

            
            RT.Rows.Clear();
            alumnDB cod = new alumnDB();
            RT = cod.reg(Int32.Parse(SetValueForText1));

            cambio = false;

            if (RT.Rows.Count == 1)


            Pr_Nom_TB.Text = RT.Rows[0][0].ToString();
            Sg_Nom_TB.Text = RT.Rows[0][1].ToString();
            Ap_Pat_TB.Text = RT.Rows[0][2].ToString();
            Ap_Mat_TB.Text = RT.Rows[0][3].ToString();

            dateTimePicker1.Value = Convert.ToDateTime(RT.Rows[0][4].ToString());

            LugN.Text = RT.Rows[0][5].ToString();
            matricula.Text = RT.Rows[0][6].ToString();

            //7 carr
            CB_car.Text = RT.Rows[0][7].ToString();

            //8 gen


           

            if (RT.Rows[0][8].ToString() == "m") { CB_gen.Text = "masculino"; }
            else if (RT.Rows[0][8].ToString() == "f")
            { CB_gen.Text = "femenino"; }
            else
            {
                CB_gen.Text = "otro";
            }



            llenarK();

            CB_sem.Enabled = true;
            crearK.Enabled = true;

            FilCB2();
            cambio = true;
        }

        private void Cancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void CB_car_SelectedIndexChanged(object sender, EventArgs e)
        {
          
        }

        private void editar_Click(object sender, EventArgs e)
        {
            if (CB_car.Text != "")
            {
                edAlumn();
            }
            else MessageBox.Show("favor de elegir carrera");
        }

        private void edAlumn()
        {
            string Pr = Pr_Nom_TB.Text;
            string Sg = Sg_Nom_TB.Text;
            string AP = Ap_Pat_TB.Text;
            string AM = Ap_Mat_TB.Text;
            string mat = matricula.Text;
            string Nlug = LugN.Text;
            string gen = CB_gen.SelectedItem.ToString();
            int car = Int32.Parse(CB_car.SelectedValue.ToString());
            DateTime nac = dateTimePicker1.Value;

            alumnDB al = new alumnDB();

            al.modyF(Int32.Parse(SetValueForText1), Pr, Sg, AP, AM, nac, gen, Nlug, mat, car);







        }

        private void CB_car_TextUpdate(object sender, EventArgs e)
        {
         
        }

        private void CB_sem_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (CB_sem.Text != "") {
                string P = CB_sem.Text;

                if (P != "" && P != "System.Data.DataRowView" && CB_sem.SelectedValue.ToString() != "System.Data.DataRowView")
                {
                    //  MessageBox.Show(CB_GR.SelectedValue.ToString());
                    if (RT.Rows.Count > 0)
                    {
                        DataView RV = new DataView(DT);
                        RV.RowFilter = "[Periodo Escolar] ='" + CB_sem.Text+"'";

                        dataGridView1.Refresh();
                        dataGridView1.ReadOnly = true;
                        dataGridView1.DataSource = RV;

                    }
                }
            }
        }

        private void crearK_Click(object sender, EventArgs e)
        {
            using (StreamWriter outputfile = new StreamWriter("C:\\Users\\fer\\Desktop\\" + matricula.Text + ".txt")) {
                outputfile.WriteLine("alumno:    "+Pr_Nom_TB.Text + " "+ Sg_Nom_TB.Text + " " + Ap_Pat_TB.Text + " " + Ap_Mat_TB.Text + "\n");
                outputfile.WriteLine("matricula: "+matricula.Text +"\n");

                outputfile.WriteLine("carrera:   " + CB_car.Text + "\n");
                outputfile.WriteLine("materias    calificacion    \n");

                if (DT.Rows.Count > 0)
                {
                    for (int i=0;i<= DT.Rows.Count-1;i++)
                    outputfile.WriteLine(DT.Rows[i][0].ToString()+"         "+ DT.Rows[i][1].ToString()+ "\n");

                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("seguro?", "dar de baja alumno", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                alumnDB al = new alumnDB();
                al.baja(Int32.Parse(SetValueForText1));
                this.Close();
            }
            
        }
           
    }
}
