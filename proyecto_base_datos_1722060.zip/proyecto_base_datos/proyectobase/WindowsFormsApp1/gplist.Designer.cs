﻿namespace WindowsFormsApp1
{
    partial class gplist
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Bagr = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.CD_car = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(27, 72);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(843, 268);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // Bagr
            // 
            this.Bagr.Location = new System.Drawing.Point(27, 368);
            this.Bagr.Name = "Bagr";
            this.Bagr.Size = new System.Drawing.Size(138, 50);
            this.Bagr.TabIndex = 1;
            this.Bagr.Text = "agregar";
            this.Bagr.UseVisualStyleBackColor = true;
            this.Bagr.Click += new System.EventHandler(this.Bagr_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(732, 368);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(138, 50);
            this.button2.TabIndex = 2;
            this.button2.Text = "salir";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // CD_car
            // 
            this.CD_car.FormattingEnabled = true;
            this.CD_car.Location = new System.Drawing.Point(236, 24);
            this.CD_car.Name = "CD_car";
            this.CD_car.Size = new System.Drawing.Size(517, 24);
            this.CD_car.TabIndex = 3;
            this.CD_car.SelectedIndexChanged += new System.EventHandler(this.CD_car_SelectedIndexChanged);
            // 
            // gplist
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(882, 450);
            this.Controls.Add(this.CD_car);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.Bagr);
            this.Controls.Add(this.dataGridView1);
            this.Name = "gplist";
            this.Text = "gplist";
            this.Activated += new System.EventHandler(this.gplist_Activated);
            this.Load += new System.EventHandler(this.gplist_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button Bagr;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ComboBox CD_car;
    }
}