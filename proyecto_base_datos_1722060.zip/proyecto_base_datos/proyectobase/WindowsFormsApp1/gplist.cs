﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class gplist : Form
    {
        private DataTable DT = new DataTable();
        private DataTable RT = new DataTable();
        public static string SeTV1 = "";
        public static string tp = "";
        private static int tC;
        private static int PE;
        public static Boolean Act = false;

        public gplist()
        {
            InitializeComponent();
            tC = 0;
            PE = inicio.IDPE;
            tp = inicio.VAL;
        }
        public gplist(int car, int sem, string val)
        {
            InitializeComponent();
            tC = car;
            PE = sem;
            tp = val;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void gplist_Load(object sender, EventArgs e)
        {

            if (tp == "1" || tp == "4")
                Bagr.Enabled = true;
            else
                Bagr.Enabled = false;
            actualizarT();
            FilCB(tC);

            if (tC > 0)
                CD_car.SelectedValue = tC;


        }

        private void actualizarT()
        {

            RT.Rows.Clear();
            dataGridView1.Refresh();
            dataGridView1.ReadOnly = true;
            dataGridView1.DataSource = RT;




            grpDB tab = new grpDB();

            RT = tab.listtotal(PE);




            if (RT.Rows.Count > 0)
            {

                dataGridView1.ReadOnly = true;
                dataGridView1.DataSource = RT;
                dataGridView1.AutoResizeColumns();
                dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            }
            else
            {
                MessageBox.Show("sin materias");
            }

            Act = true;

            if (inicio.VAL == "1")
            {
                Bagr.Enabled = true;
            }


        }


        private void FilCB(int SeT)
        {
            DT.Rows.Clear();
            CD_car.DisplayMember = "";
            CD_car.ValueMember = "";

            CarDB cox = new CarDB();

            DT = cox.CBcar_A(SeT);

            CD_car.DataSource = DT;
            CD_car.DisplayMember = "nombre";
            CD_car.ValueMember = "id";
            CD_car.DataSource = DT;

            CD_car.SelectedIndex = -1;
        }

        private void Bagr_Click(object sender, EventArgs e)
        {
            OPEN();
        }

        private void OPEN() {
            grupos GRP = new grupos(tC, tp, PE);
            GRP.ShowDialog();
            Act = false;
        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void select(DataGridViewCellEventArgs e) {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow select = this.dataGridView1.Rows[e.RowIndex];
                //  SetValueForText1 = this.dataGridView1[e.ColumnIndex, e.RowIndex].Value.ToString();
            }


            if (Convert.ToString(dataGridView1.CurrentRow.Cells[0].Value) != "")
            {
                int index = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value);

                if (dataGridView1.SelectedCells.Count >= 0)
                {
                    int selectedrowindex = dataGridView1.SelectedCells[0].RowIndex;

                    DataGridViewRow selectedRow = dataGridView1.Rows[selectedrowindex];

                    string a = Convert.ToString(selectedRow.Cells["id"].Value);

                    SeTV1 = a;

                    OPEN();

                }
            }
        }

        private void gplist_Activated(object sender, EventArgs e)
        {
            if (Act == false) {
                actualizarT();
                FilCB(tC);

                if (tC > 0)
                    CD_car.SelectedValue = tC;


            }
          
        }


        private void cambio()
        {

            DataView DV = new DataView(RT);
            dataGridView1.DataSource = DV;
            if (CD_car.SelectedIndex > -1)
            {
                string T = CD_car.Text;

                DV.RowFilter = "carrera =" + "'" + T + "'";

            }

            dataGridView1.ReadOnly = true;

            dataGridView1.AutoResizeColumns();
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

        }

        private void CD_car_SelectedIndexChanged(object sender, EventArgs e)
        {
            cambio();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            select(e);
        }
    }
}
