﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    class grpDB:ConDB
    {
        DataTable RTGP = new DataTable();
      
       

       

        public DataTable listtotal(int sem)
        {
            
            RTGP = GP_listtotal(sem);
            return RTGP;
        }

        public DataTable listaula()
        {
          
            RTGP = GP_listaula();
            return RTGP;
        }

        public DataTable listmat()
        {
            
            RTGP = GP_listmat();
            return RTGP;
        }

        public DataTable horas(int idA,int sem)
        {
            
         
            RTGP = GP_horas(idA,sem);
            return RTGP;
        }

        public void novcls(int A, int S, int M,int G)
        {
            
            GP_novcls(A, S,M,G);

            //try
            //{
            //    conectar();
            //    SqlCommand cmd = new SqlCommand(ProD5, _conexion);

            //    //cmd.Parameters.Clear();


            //    cmd.CommandType = CommandType.StoredProcedure;

            //    cmd.Parameters.AddWithValue("@idG", G);
            //    cmd.Parameters.AddWithValue("@idA", A);
            //    cmd.Parameters.AddWithValue("@idM", M);
            //    cmd.Parameters.AddWithValue("@idE", "");
            //    cmd.Parameters.AddWithValue("@idS", S);
            //    cmd.Parameters.AddWithValue("@opc", "Nov");



            //    _conexion.Open();

            //    cmd.ExecuteNonQuery();


            //    desconectar();
            //    MessageBox.Show("clase creada");

            //}

            //catch (SqlException ex)
            //{
            //    desconectar();
            //    MessageBox.Show(ex.ToString());
            //}


        }

        public DataTable modde(int id)
        {
           
           
            RTGP = GP_modde(id);

            return RTGP;
        }

        public DataTable listgr(int sem)
        {
            

            RTGP = GP_listgr(sem);
            return RTGP;
        }

        public void crg(int A, int S, int M, int G)
        {

            GP_chgr(A, S, M, G);

            


        }

    }
}
