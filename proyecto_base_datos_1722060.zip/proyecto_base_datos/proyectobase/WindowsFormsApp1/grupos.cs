﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class grupos : Form
    {
        private DataTable AT = new DataTable();
        private DataTable MT = new DataTable();
        private DataTable CT = new DataTable();
        private DataTable DT = new DataTable();
        public static string SeTV1 = "";
        public static string PE= "";
        public static Boolean Act = false;
        private int ca;
        private int SP;
        private int indexA;
        int matt;
        int Aull;
        int Peri;
    

        public grupos()
        {
            InitializeComponent();
            ca = 0;
           PE = inicio.VAL;
            SP = inicio.IDPE;
        }

        public grupos(int c,string VAL,int P_E )
        {
            InitializeComponent();
            PE = VAL;
            ca = c;
            SP = P_E;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void grupos_Load(object sender, EventArgs e)
        {
            actMT();
            actAT();
            SeTV1 = gplist.SeTV1;

            if (SeTV1 != "")
            {

                int A = Convert.ToInt32(SeTV1);
                modC(A);
                
                button1.Enabled = false;
            }
            else {
                indexA = 0;
                button3.Enabled = false;
            }

            if (PE!= "1")
                button1.Enabled = false;
        }

        private void actMT()
        {

            MT.Rows.Clear();
            dataGridView1.Refresh();
            dataGridView1.ReadOnly = true;
            dataGridView1.DataSource = MT;




            grpDB tab = new grpDB();

            MT = tab.listmat();




            if (MT.Rows.Count > 0)
            {


                DataView DV = new DataView(MT);
                dataGridView1.DataSource = DV;
                if (ca > 0)
                {
                    CarDB carr = new CarDB();
                   CT= carr.selcar(ca);

                    DV.RowFilter = "carrera =" + "'" + CT.Rows[0][0].ToString() + "'";

                }




                dataGridView1.ReadOnly = true;
                dataGridView1.DataSource = DV;
                dataGridView1.AutoResizeColumns();
                dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            }
            else
            {
                MessageBox.Show("sin materias");
            }

            Act = true;

           


        }

        private void actAT()
        {

            AT.Rows.Clear();
            dataGridView2.Refresh();
            dataGridView2.ReadOnly = true;
            dataGridView2.DataSource = AT;




            grpDB tab = new grpDB();

            AT = tab.listaula();




            if (MT.Rows.Count > 0)
            {

                dataGridView2.ReadOnly = true;
                dataGridView2.DataSource = AT;
                dataGridView2.AutoResizeColumns();
                dataGridView2.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            }
            else
            {
                MessageBox.Show("sin aulas");
            }

            Act = true;




        }

        private void button1_Click(object sender, EventArgs e)
        {
            crea();
        }

        private void crea() {
            grpDB GRUPO = new grpDB();

            if (TBM.Text != "" && TBA.Text != "")
            {

                if (dataGridView1.SelectedCells.Count >= 0 && dataGridView2.SelectedCells.Count >= 0)
                {
                    int Hr = Convert.ToInt32(dataGridView1.CurrentRow.Cells[4].Value);
                    int Sem = SP;
                    int AI;





                    int indexM = Convert.ToInt32(TBM.Text);
                    int indexA = Convert.ToInt32(TBA.Text);

                    DataTable aux = new DataTable();
                    aux = GRUPO.horas(indexA, Sem);

                    if (aux.Rows.Count > 0)
                    {
                        AI = Convert.ToInt32(aux.Rows[0][0].ToString());
                    }
                    else { AI = 0; }

                    if ((AI + Hr) <= 40)
                    {

                        GRUPO.novcls(indexA, Sem, indexM, Convert.ToInt32(num.Value));

                        this.Close();
                    }
                    else { MessageBox.Show("aula sin horarios disponibles"); }
                }
                else { MessageBox.Show("favor de seleccionar todos los datos"); }
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            mody();
        }

        private void mody() {
            grpDB GRUPO = new grpDB();

            if (TBM.Text != "" && TBA.Text != "")
            {

                if (dataGridView1.SelectedCells.Count >= 0 && dataGridView2.SelectedCells.Count >= 0)
                {
                    int Hr = Convert.ToInt32(dataGridView1.CurrentRow.Cells[4].Value);
                    int Sem = SP;
                    int AI;





                    int indexM = Convert.ToInt32(TBM.Text);
                    int indexA2 = Convert.ToInt32(TBA.Text);

                    DataTable aux = new DataTable();
                    aux = GRUPO.horas(indexA2, Sem);

                    if (aux.Rows.Count > 0&&indexA2!=indexA)
                    {
                        AI = Convert.ToInt32(aux.Rows[0][0].ToString());
                    }
                    else { AI = 0; }

                    if ((AI + Hr) <= 40)
                    {
                      //  int id,int aul, int gpo,int mat
                        GRUPO.crg(Convert.ToInt32(SeTV1),indexA2, indexM, Convert.ToInt32(num.Value));

                        this.Close();
                    }
                    else { MessageBox.Show("aula sin horarios disponibles"); }
                }
                else { MessageBox.Show("favor de seleccionar todos los datos"); }
            }

        }

        private void modC(int IDE) {
            grpDB tab = new grpDB();
            DataTable aux = new DataTable();

            aux = tab.modde(IDE);

            int indexM = Convert.ToInt32(aux.Rows[0][0].ToString());
             indexA = Convert.ToInt32(aux.Rows[0][1].ToString());
            int indexG = Convert.ToInt32(aux.Rows[0][2].ToString());

            TBM.Text = indexM.ToString();
            TBA.Text = indexA.ToString();
            num.Value = indexG;

            //dataGridView1.CurrentCell = dataGridView1.DataMember[0] = indexM;
            //dataGridView1.Rows.Where(x => (int)x.Cells["Id"].Value == pId);

            actTABLE2();
        }

        private void actTABLE2()
        {
            DT.Rows.Clear();

            dataGridView3.Refresh();
            dataGridView3.ReadOnly = true;
            dataGridView3.DataSource = DT;
            int car=0;

            TAC tab = new TAC();

            string P = SeTV1;

            if (P != "" && P != "System.Data.DataRowView")
            {

                car = Convert.ToInt32(SeTV1);
            }


            DT = tab.list2(car, SP);

            if (DT.Rows.Count > 0)
            {
                DataView DV2 = new DataView(DT);



                dataGridView3.Columns.Clear();
                dataGridView3.ReadOnly = true;
                dataGridView3.DataSource = DV2;



                dataGridView3.AutoResizeColumns();

                dataGridView3.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            }
            else
            {
                MessageBox.Show("no hay alumnos inscritos");
            }

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {if(PE=="1")
            TBM.Text = Convert.ToString(dataGridView1.CurrentRow.Cells[0].Value);
        }

        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (PE == "1")
                TBA.Text = Convert.ToString(dataGridView2.CurrentRow.Cells[0].Value);
        }
    }
}
