﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class incoord : Form
    {
        private DataTable DT = new DataTable();

        private DataTable MT = new DataTable();
        private static Boolean Act = false;
        private int idc;
        private int carr;
        private static string VAL;
        private static int IDPE;
        public incoord()
        {
            InitializeComponent();
        }
        public incoord(string L,int id)
        {
            InitializeComponent();
            label1.Text = L;
            idc = id;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void per_esc()
        {

            semDB P_E = new semDB();

            DT = P_E.perAct();

            if (DT.Rows.Count == 1)

            {
                label2.Text = DT.Rows[0][1].ToString();
                VAL = DT.Rows[0][2].ToString();
                label3.Text = DT.Rows[0][3].ToString();
                IDPE = Int32.Parse(DT.Rows[0][0].ToString());

                //if (VAL == "1")
                //{
                //    I_S.Enabled = false;
                //    button2.Enabled = true;
                //    A_I.Enabled = true;
                //    F_S.Enabled = false;
                //}
                //else if (VAL == "2")
                //{
                //    I_S.Enabled = false;
                //    button2.Enabled = false;
                //    A_I.Enabled = false;
                //    F_S.Enabled = true;
                //}
                //else if (VAL == "3")
                //{
                //    I_S.Enabled = false;
                //    A_I.Enabled = true;
                //    button2.Enabled = false;
                //    F_S.Enabled = false;
                //}
                //else if (VAL == "4")
                //{
                //    I_S.Enabled = true;
                //    A_I.Enabled = false;
                //    F_S.Enabled = false;
                //    button2.Enabled = false;

                //}

            }

        }

        private void datosC()
        {

            ConDB P_E = new ConDB();

            DT = P_E.incor(idc);

            if (DT.Rows.Count == 1)
            {

                label4.Text = DT.Rows[0][0].ToString();
                label5.Text = DT.Rows[0][1].ToString();
                label6.Text = DT.Rows[0][2].ToString();
                carr= Int32.Parse(DT.Rows[0][3].ToString());
            }

        }

        private void incoord_Load(object sender, EventArgs e)
        {
            per_esc();
            datosC();
           
        }

   

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            materias mat = new materias(carr);
            mat.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            alumnos vent = new alumnos(label1.Text,carr,VAL);
            vent.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            aulas au = new aulas();
            au.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            gplist gp = new gplist(carr,IDPE,VAL);
            gp.ShowDialog();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            clif calif = new clif(carr, IDPE);
            calif.ShowDialog();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            inscrip vent = new inscrip(IDPE,2,carr);
            vent.ShowDialog();
        }
    }
}
