﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class inicio : Form
    {
        private DataTable DT = new DataTable();


        public static Boolean Act = false;
        private string mystring = "";
        private string res;
        public static string VAL;
        public static int IDPE;
        public inicio()
        {
            InitializeComponent();
        }

        public inicio( string L)
        {
            InitializeComponent();
            label1.Text = L;
        }

        private void inicio_Load(object sender, EventArgs e)
        {

            per_esc();


        }

        private void faltacord()
        { 
           DataTable MT = new DataTable();
             CarDB con = new CarDB();
            MT = con.listfalt();

            if (MT.Rows.Count > 0)
            {
                
                for (int i = 0; i <= MT.Rows.Count - 1; i++)
                {
                    string cell = MT.Rows[i][0].ToString();
                    CarED edi = new CarED(cell);
                    edi.ShowDialog();
                }


            }

        }


        private void button1_Click(object sender, EventArgs e)
        {
            coordinadores v0 = new coordinadores();
            v0.ShowDialog();
        }

        private void salir_Click(object sender, EventArgs e)
        {
            this.Close();

        }

        private void B_CA_Click(object sender, EventArgs e)
        {
           carreras v3 = new carreras();
           v3.ShowDialog();
        }


        private void per_esc()
        {

            semDB P_E = new semDB();

            DT = P_E.perAct();

            if (DT.Rows.Count == 1)


                label2.Text = DT.Rows[0][1].ToString();
            VAL = DT.Rows[0][2].ToString();
            label3.Text = DT.Rows[0][3].ToString();
            IDPE= Int32.Parse(DT.Rows[0][0].ToString());

            if (VAL == "1")
            {
                I_S.Enabled = false;
                button2.Enabled = true;
                A_I.Enabled = true;
                F_S.Enabled = false;
            }
            else if (VAL == "2")
            {
                I_S.Enabled = false;
                button2.Enabled =false;
                A_I.Enabled = false;
                F_S.Enabled = true;
            }
            else if (VAL == "3")
            {
                I_S.Enabled = false;
                A_I.Enabled = true;
                button2.Enabled = false;
                F_S.Enabled = false;
            }
            else if (VAL == "4")
            {
                I_S.Enabled = true;
                A_I.Enabled = false;
                F_S.Enabled = false;
                button2.Enabled = false;

            }



        }

        private void button2_Click(object sender, EventArgs e)
        {
            semestre sem = new semestre();
            sem.ShowDialog();
            //mystring = label2.Text;

            //if (mystring.Length > 4)
            //    res = GetLast(mystring, 4);
            //else
            //    res = "";


            //semDB P_E = new semDB();
            //P_E.newSem(res, IDPE);

            per_esc();

        }

        private void A_I_Click(object sender, EventArgs e)
        {
            semDB P_E = new semDB();
            P_E.CerIns(IDPE);

            per_esc();

        }

        private void button4_Click(object sender, EventArgs e)
        {
                     DataTable DT2 = new DataTable();

            TAC ti = new TAC();
            // ti.final();
            DT2=ti.chefin(IDPE);

            if (DT2.Rows.Count <= 0)
            {
                semDB P_E = new semDB();
                P_E.FinSem(IDPE);

                per_esc();
            }
            else MessageBox.Show("falta calificar materias");


        }


        private string GetLast(string source, int tail_length)
        {
            if (tail_length >= source.Length)
                return source;
            return source.Substring(source.Length - tail_length);
        }


        private void inicio_FormClosed(object sender, FormClosedEventArgs e)
        {

        }

        private void B_alum_Click(object sender, EventArgs e)
        {
            alumnos alu = new alumnos();
            alu.ShowDialog();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void B_mat_Click(object sender, EventArgs e)
        {
            materias mat = new materias();
            mat.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            aulas AL = new aulas();
            AL.ShowDialog();
        }

        private void BtGru_Click(object sender, EventArgs e)
        {
            gplist grup = new gplist();
            grup.ShowDialog();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            inscrip ins = new inscrip(IDPE);
                ins.ShowDialog();
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            clif calif = new clif(0,IDPE);
            calif.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            reportes rep = new reportes();
            rep.ShowDialog();
        }
    }
}
