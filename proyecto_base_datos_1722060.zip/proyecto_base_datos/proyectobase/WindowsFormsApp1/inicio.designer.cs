﻿namespace WindowsFormsApp1
{
    partial class inicio
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.salir = new System.Windows.Forms.Button();
            this.B_CA = new System.Windows.Forms.Button();
            this.I_S = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.A_I = new System.Windows.Forms.Button();
            this.F_S = new System.Windows.Forms.Button();
            this.B_alum = new System.Windows.Forms.Button();
            this.B_mat = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.BtGru = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(31, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "label1";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(34, 80);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(115, 54);
            this.button1.TabIndex = 1;
            this.button1.Text = "coordinadores";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // salir
            // 
            this.salir.Location = new System.Drawing.Point(34, 478);
            this.salir.Name = "salir";
            this.salir.Size = new System.Drawing.Size(313, 41);
            this.salir.TabIndex = 2;
            this.salir.Text = "salir";
            this.salir.UseVisualStyleBackColor = true;
            this.salir.Click += new System.EventHandler(this.salir_Click);
            // 
            // B_CA
            // 
            this.B_CA.Location = new System.Drawing.Point(34, 147);
            this.B_CA.Name = "B_CA";
            this.B_CA.Size = new System.Drawing.Size(115, 41);
            this.B_CA.TabIndex = 3;
            this.B_CA.Text = "carreras";
            this.B_CA.UseVisualStyleBackColor = true;
            this.B_CA.Click += new System.EventHandler(this.B_CA_Click);
            // 
            // I_S
            // 
            this.I_S.Location = new System.Drawing.Point(232, 80);
            this.I_S.Name = "I_S";
            this.I_S.Size = new System.Drawing.Size(115, 54);
            this.I_S.TabIndex = 4;
            this.I_S.Text = "iniciar semestre";
            this.I_S.UseVisualStyleBackColor = true;
            this.I_S.Click += new System.EventHandler(this.button2_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(242, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(46, 17);
            this.label2.TabIndex = 5;
            this.label2.Text = "label2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(242, 35);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(46, 17);
            this.label3.TabIndex = 6;
            this.label3.Text = "label3";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // A_I
            // 
            this.A_I.Location = new System.Drawing.Point(232, 203);
            this.A_I.Name = "A_I";
            this.A_I.Size = new System.Drawing.Size(115, 56);
            this.A_I.TabIndex = 7;
            this.A_I.Text = "acabar inscripciones";
            this.A_I.UseVisualStyleBackColor = true;
            this.A_I.Click += new System.EventHandler(this.A_I_Click);
            // 
            // F_S
            // 
            this.F_S.Location = new System.Drawing.Point(232, 336);
            this.F_S.Name = "F_S";
            this.F_S.Size = new System.Drawing.Size(115, 56);
            this.F_S.TabIndex = 8;
            this.F_S.Text = "finalizar semestre";
            this.F_S.UseVisualStyleBackColor = true;
            this.F_S.Click += new System.EventHandler(this.button4_Click);
            // 
            // B_alum
            // 
            this.B_alum.Location = new System.Drawing.Point(34, 203);
            this.B_alum.Name = "B_alum";
            this.B_alum.Size = new System.Drawing.Size(115, 56);
            this.B_alum.TabIndex = 10;
            this.B_alum.Text = "alumnos";
            this.B_alum.UseVisualStyleBackColor = true;
            this.B_alum.Click += new System.EventHandler(this.B_alum_Click);
            // 
            // B_mat
            // 
            this.B_mat.Location = new System.Drawing.Point(34, 270);
            this.B_mat.Name = "B_mat";
            this.B_mat.Size = new System.Drawing.Size(115, 55);
            this.B_mat.TabIndex = 11;
            this.B_mat.Text = "materias";
            this.B_mat.UseVisualStyleBackColor = true;
            this.B_mat.Click += new System.EventHandler(this.B_mat_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(34, 336);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(115, 56);
            this.button3.TabIndex = 12;
            this.button3.Text = "aulas";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // BtGru
            // 
            this.BtGru.Location = new System.Drawing.Point(34, 407);
            this.BtGru.Name = "BtGru";
            this.BtGru.Size = new System.Drawing.Size(115, 41);
            this.BtGru.TabIndex = 13;
            this.BtGru.Text = "grupos";
            this.BtGru.UseVisualStyleBackColor = true;
            this.BtGru.Click += new System.EventHandler(this.BtGru_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(232, 147);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(115, 41);
            this.button2.TabIndex = 14;
            this.button2.Text = "inscribir";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(232, 270);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(115, 55);
            this.button4.TabIndex = 15;
            this.button4.Text = "calificaciones";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click_1);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(232, 407);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(115, 41);
            this.button5.TabIndex = 16;
            this.button5.Text = "reportes";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // inicio
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(407, 531);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.BtGru);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.B_mat);
            this.Controls.Add(this.B_alum);
            this.Controls.Add(this.F_S);
            this.Controls.Add(this.A_I);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.I_S);
            this.Controls.Add(this.B_CA);
            this.Controls.Add(this.salir);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Name = "inicio";
            this.Text = "inicio";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.inicio_FormClosed);
            this.Load += new System.EventHandler(this.inicio_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button salir;
        private System.Windows.Forms.Button B_CA;
        private System.Windows.Forms.Button I_S;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button A_I;
        private System.Windows.Forms.Button F_S;
        private System.Windows.Forms.Button B_alum;
        private System.Windows.Forms.Button B_mat;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button BtGru;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
    }
}