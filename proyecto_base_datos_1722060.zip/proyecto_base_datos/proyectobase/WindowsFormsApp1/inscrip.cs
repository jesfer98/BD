﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class inscrip : Form
    {
        DataTable DT = new DataTable();
        DataTable DT2 = new DataTable();
        DataTable CT = new DataTable();
        DataTable MT = new DataTable();
        DataTable GR = new DataTable();
        private static Boolean ACTIVO=true;
        private int typ, car;
        private int IDPE;
        public inscrip()
        {
            InitializeComponent();
        }

        public inscrip(int SE)
        {
            InitializeComponent();
            IDPE = SE;
            typ = 1;
            car = 0;
        }

        public inscrip(int SE,int TP,int CP )
        {
            InitializeComponent();
            IDPE = SE;
            typ = TP;
            car = CP;
        }

        private void inscrip_Load(object sender, EventArgs e)
        {

           // actualizarT();
            FilCB(car);
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            agre();
        }

        private void agre() {

            int A = ListAlLib.RowCount;

            TAC reg = new TAC();

            for (int i = 0; i < A; i++)
            {//chexk
                if ((ListAlLib.Rows[i].Cells[4].Value) != null)
                {
                    DataTable aux = new DataTable();
                    DataTable aux2 = new DataTable();
                    DataTable aux3 = new DataTable();
                    DataTable aux4 = new DataTable();
                    DataTable aux5 = new DataTable();
                    DataTable aux6 = new DataTable();
                    DataTable aux7 = new DataTable();

                    int ida = Convert.ToInt32(Convert.ToString(ListAlLib.Rows[i].Cells[0].Value));
                    int gru = Convert.ToInt32(CB_GR.SelectedValue.ToString());
                    aux = reg.comp(ida, gru);
                    // agregar para saber cuanto son y cuantos max

                    aux2 = reg.max(gru);
                    aux3 = reg.total(gru);


                    int Ctot;
                    int Cmax = Convert.ToInt32(aux2.Rows[0][0].ToString());
                    if (aux3.Rows.Count > 0&&aux3.Rows[0][0].ToString() != "")
                    {
                        Ctot = Convert.ToInt32(aux3.Rows[0][0].ToString());
                    }
                    else Ctot = 0;

                    aux4 = reg.pase(ida, Convert.ToInt32(CB_mat.SelectedValue.ToString()));
                    int cal;
                    /////////////////checar esto
                    if (aux4.Rows.Count > 0&& aux4.Rows[0][0].ToString()!="")
                    {
                        cal = Convert.ToInt32(aux4.Rows[0][0].ToString());
                    }
                    else cal = 0;
                    aux5 = reg.cre(ida, IDPE);

                    int crA;
                    if (aux5.Rows.Count > 0&& aux5.Rows[0][0].ToString() != "")
                    {
                        crA = Convert.ToInt32(aux5.Rows[0][0].ToString());
                    } else crA = 0;

                    aux6 = reg.PE(IDPE);
                    int crS;
                    if (aux6.Rows.Count > 0&&aux6.Rows[0][0].ToString() != "")
                    {
                        crS = Convert.ToInt32(aux6.Rows[0][0].ToString());
                    }
                    else crS = 0;

                    aux7 = reg.crM(gru);
                    int crM;
                    if (aux7.Rows.Count > 0&& aux7.Rows[0][0].ToString() != "")
                    {
                        crM = Convert.ToInt32(aux7.Rows[0][0].ToString());
                    }
                    else crM = 0;

                    if (crA + crM <= crS)
                    {
                        if (aux.Rows.Count < 1 && Ctot < Cmax && cal < 70)
                        {
                            reg.regist(ida, IDPE, gru);
                        }
                        else { MessageBox.Show(Convert.ToString(ListAlLib.Rows[i].Cells[1].Value) + " materia aprovada"); }
                    } else if (crA + crM > crS)
                    { MessageBox.Show(Convert.ToString(ListAlLib.Rows[i].Cells[1].Value) + " credios insuficientes");
                    }
                }
            }

            ACTIVO = false;
        }

        private void actualizarT()
        {

            DT.Rows.Clear();
            dataGridView1.Refresh();
            dataGridView1.ReadOnly = true;
            dataGridView1.DataSource = DT;



            //if (Form1.SetValueForText1 == "administrador")
            //{
            //    typ = 1;
            //    car = 0;
            //}
            //else if (Form1.SetValueForText1 == "coordinador")
            //{
            //    typ = 2;
            //    car = 2;
            //}
            //else
            //{
            //    typ = 0;
            //    car = 0;
            //}

            alumnDB tab = new alumnDB();

            DT = tab.listalumn(2, car);

            if (DT.Rows.Count > 0)
            {
                DataView DV = new DataView(DT);


                DataGridViewCheckBoxColumn checkColumn = new DataGridViewCheckBoxColumn();
                dataGridView1.ReadOnly = false;
                dataGridView1.DataSource = DV;
                checkColumn.Name = "X";
                checkColumn.HeaderText = "X";
              
                     
                dataGridView1.AutoResizeColumns();
                dataGridView1.Columns.Add(checkColumn);
                checkColumn.TrueValue = 1;
                checkColumn.FalseValue = 0;

                dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
               
            }
            else
            {
                MessageBox.Show("no hay alumnos inscritos");
            }

            
        }


        private void carr() { FilCB(car); }

        private void cambio()
        {

            DataView DV = new DataView(MT);
            //dataGridView1.DataSource = DV;
            if (CB_car.SelectedIndex > -1)
            {
                string T = CB_car.Text;

                DV.RowFilter = "carrera =" + "'" + T + "'";

            }

            //dataGridView1.ReadOnly = true;

            //dataGridView1.AutoResizeColumns();
            //dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

        }


        private void FilCB(int SeT)
        {
            CT.Rows.Clear();
            CB_car.DisplayMember = "";
            CB_car.ValueMember = "";

            CarDB cox = new CarDB();

            CT = cox.CBcar_A(SeT);

            CB_car.DataSource = CT;
            CB_car.DisplayMember = "nombre";
            CB_car.ValueMember = "id";
            CB_car.DataSource = CT;
            CB_car.SelectedIndex = -1;
        }

        private void CB_car_SelectedIndexChanged(object sender, EventArgs e)
        {
            // if(CB_car.SelectedValue.ToString()!=null)
            ListAlLib.DataSource = null;
            ListAlLib.Columns.Clear();
            dataGridView1.DataSource = null;
            dataGridView1.Columns.Clear();

            if (CB_car.Text != "")
            {
                //MessageBox.Show(CB_car.SelectedValue.ToString());
                FilMB();
            }
        }

        private void FilMB()
        {
            CB_mat.DisplayMember = "";
            CB_mat.ValueMember = "";
            int T;
            matDB cox = new matDB();

           string  P = CB_car.Text;
            MT = cox.lista2();

            DataView MV = new DataView(MT);
            if (P != ""&&P!= "System.Data.DataRowView"&& CB_car.SelectedValue.ToString() != "System.Data.DataRowView")
            {
               
                T = Convert.ToInt32(CB_car.SelectedValue.ToString());
            }
            else { T = 0; }
            
            MV.RowFilter = "carrera =" + "'" + T + "'";

            CB_mat.DataSource = MV;
            CB_mat.DisplayMember = "nombre";
            CB_mat.ValueMember = "id";
            CB_mat.DataSource = MV;
            CB_mat.SelectedIndex = -1;
        }

        private void CB_mat_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (CB_mat.Text != "")
            {
                //  MessageBox.Show(CB_mat.SelectedValue.ToString());
                FilGR();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void CB_GR_SelectedIndexChanged(object sender, EventArgs e)
        {
            compro();

           
        }

        private void compro() {
            string P = CB_GR.Text;

            if (P != "" && P != "System.Data.DataRowView" && CB_GR.SelectedValue.ToString() != "System.Data.DataRowView")
            {
                //  MessageBox.Show(CB_GR.SelectedValue.ToString());


                actTABLE1();
                actTABLE2();

                ACTIVO = true;
            }
        }

        private void actTABLE1() {
            DT.Rows.Clear();
            ListAlLib.Refresh();
            ListAlLib.ReadOnly = true;
            ListAlLib.DataSource = DT;

            TAC tab = new TAC();
            typ=Convert.ToInt32(CB_car.SelectedValue.ToString());
            DT = tab.list1(typ);

            if (DT.Rows.Count > 0)
            {
                DataView DV = new DataView(DT);


                DataGridViewCheckBoxColumn checkColumn = new DataGridViewCheckBoxColumn();

                ListAlLib.Columns.Clear();
                ListAlLib.ReadOnly = false;
                ListAlLib.DataSource = DV;
                checkColumn.Name = "X";
                checkColumn.HeaderText = "X";


                ListAlLib.AutoResizeColumns();
                ListAlLib.Columns.Add(checkColumn);
                checkColumn.TrueValue = 1;
                checkColumn.FalseValue = 0;

                ListAlLib.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            }
            else
            {
                MessageBox.Show("no hay alumnos inscritos");
            }

        }

        private void actTABLE2()
        {
            DT2.Rows.Clear();

            dataGridView1.Refresh();
            dataGridView1.ReadOnly = true;
            dataGridView1.DataSource = DT2;

            TAC tab = new TAC();

            string P = CB_GR.Text;

            if (P != "" && P != "System.Data.DataRowView" && CB_GR.SelectedValue.ToString() != "System.Data.DataRowView")
            {

                car = Convert.ToInt32(CB_GR.SelectedValue.ToString());
            }


            DT2 = tab.list2(car,IDPE);

            if (DT2.Rows.Count > 0)
            {
                DataView DV2 = new DataView(DT2);


                DataGridViewCheckBoxColumn checkColumn2 = new DataGridViewCheckBoxColumn();
                dataGridView1.Columns.Clear();
                dataGridView1.ReadOnly = false;
                dataGridView1.DataSource = DV2;
                checkColumn2.Name = "X";
                checkColumn2.HeaderText = "X";


                dataGridView1.AutoResizeColumns();
                dataGridView1.Columns.Add(checkColumn2);
                checkColumn2.TrueValue = 1;
                checkColumn2.FalseValue = 0;

                dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            }
            else
            {
                MessageBox.Show("no hay alumnos inscritos");
            }

        }

        private void inscrip_Activated(object sender, EventArgs e)
        {
            if (ACTIVO == false) {
                compro();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            elim();
        }
        private void elim()
        {

            int A = dataGridView1.RowCount;

            TAC reg = new TAC();

            for (int i = 0; i < A; i++)
            {
                if ((dataGridView1.Rows[i].Cells[4].Value) != null)
                {

                    int ida = Convert.ToInt32(Convert.ToString(dataGridView1.Rows[i].Cells[0].Value));
                    int gru = Convert.ToInt32(CB_GR.SelectedValue.ToString());

                    // agregar para saber cuanto son y cuantos max



                    DialogResult dialogResult = MessageBox.Show(Convert.ToString(dataGridView1.Rows[i].Cells[1].Value)+ "  seguro?", "sacar alumno de la clase", MessageBoxButtons.YesNo);
                    if (dialogResult == DialogResult.Yes)
                    {

                        reg.borra(ida, gru);
                        //else 
                        ACTIVO = false;
                        MessageBox.Show("alumnos eliminado de clase");
                    }
                }
                
            }

            
        }

        private void inscrip_MouseEnter(object sender, EventArgs e)
        {
            if (ACTIVO == false)
            {
                compro();
            }
        }

        private void FilGR()
        {
            CB_GR.DisplayMember = "";
            CB_GR.ValueMember = "";
            int T;
            grpDB cox = new grpDB();

            string P = CB_mat.Text;
            GR = cox.listgr(IDPE);

            DataView GV = new DataView(GR);
            if (P != "" && P != "System.Data.DataRowView" && CB_mat.SelectedValue.ToString() != "System.Data.DataRowView")
            {
                T = Convert.ToInt32(CB_mat.SelectedValue.ToString());
            }
            else { T = 0; }

            GV.RowFilter = "materia =" + "'" + T + "'";

            
            CB_GR.DataSource = GV;
            CB_GR.DisplayMember = "grupo";
            CB_GR.ValueMember = "id";
            CB_GR.DataSource = GV;
            CB_GR.SelectedIndex = -1;
        }
    }
}
