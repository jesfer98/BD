﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;
using System.Data;
using System.Threading.Tasks;

using System.Configuration;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{

    public class llave: ConDB
    {
        
           public static DataTable passa(string C, string P, string T)
        {
            DataTable DT = new DataTable();
            ConDB conexion = new ConDB();

           DT=conexion.auten(C,P,T);

            return DT;
        }

    }
    
}
