﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;
namespace WindowsFormsApp1
{
    class matDB:ConDB
    {


        DataTable RTM = new DataTable();
 

     


   


        public void novoalumM(string nombre, string clave, int cred, int HS,int carr,string desc)
        {
            M_novoalum(nombre,clave,cred,HS,carr,desc);

           


        }

        public DataTable lista(int id, int typ) {
         
            RTM = M_lista(id,typ);
            return RTM;
        }

        public DataTable regisH(int id)
        {


          
           
            RTM = M_regis(id);

            return RTM;
        }

        public void modreg(int id,string nombre, string clave, int cred, int HS, int carr, string desc)
        {
            
            M_modreg(id,nombre,clave,cred,HS,carr,desc);

            
        }

        public DataTable lista2()
        {
          
            
            RTM = M_lista2();
            return RTM;
        }
    }
}
