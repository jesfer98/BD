﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class materias : Form
    {

        private DataTable DT = new DataTable();
        private DataTable RT = new DataTable();
        public static string SeTV1 = "";
        private int PerEsc;
        private int typ, car;
        public static Boolean Act = false;

        public static int TAC;

        public materias()
        {
            InitializeComponent();
            typ = 0;
        }
        public materias(int i)
        {
            InitializeComponent();
            typ = i;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void agregar_Click(object sender, EventArgs e)
        {
            SeTV1 = "";
            OP_ed();
        }

        private void materias_Load(object sender, EventArgs e)
        {
            car = 1;
            //  agregar.Enabled = false;
            Act = false;

            actualizarT(0, 0);

            FilCB(typ);

            if (typ > 0)
            {
                CD_car.SelectedValue = typ;
            }
            car = 0;

        }

        private void FilCB(int SeT)
        {
            DT.Rows.Clear();
            CD_car.DisplayMember = "";
            CD_car.ValueMember = "";

            CarDB cox = new CarDB();

            DT = cox.CBcar_A(SeT);

            CD_car.DataSource = DT;
            CD_car.DisplayMember = "nombre";
            CD_car.ValueMember = "id";
            CD_car.DataSource = DT;
            CD_car.SelectedIndex = -1;
        }

        private void CD_car_SelectedIndexChanged(object sender, EventArgs e)
        {
            cambio();
            
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void OP_ed()
        {
            Act = false;
            ED_mat editor = new ED_mat(typ);
            editor.ShowDialog();
        }

        private void CD_car_DisplayMemberChanged(object sender, EventArgs e)
        {
           
        }

        private void CD_car_Click(object sender, EventArgs e)
        {
            
        }


        private void cambio() {
         
            DataView DV = new DataView(RT);
            dataGridView1.DataSource = DV;
            if (CD_car.SelectedIndex >-1)
            {
                string T = CD_car.Text;

                DV.RowFilter = "carrera =" + "'" + T + "'";

            }

            dataGridView1.ReadOnly = true;

            dataGridView1.AutoResizeColumns();
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

        }

        private void CD_car_SelectedValueChanged(object sender, EventArgs e)
        {
          

        }

       

        private void materias_Activated(object sender, EventArgs e)
        {
            if (Act == false) {
                actualizarT(0, 0);
                FilCB(typ);
                if (typ > 0)
                {
                    CD_car.SelectedValue = typ;
                }
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            select(e);
        }

        private void select(DataGridViewCellEventArgs e) {

            if (e.RowIndex >= 0)
            {
                DataGridViewRow select = this.dataGridView1.Rows[e.RowIndex];
                //  SetValueForText1 = this.dataGridView1[e.ColumnIndex, e.RowIndex].Value.ToString();
            }
            //label1.Text=SetValueForText1;
            if (Convert.ToString(dataGridView1.CurrentRow.Cells[0].Value) != "")
            {
                int index = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value);

                if (dataGridView1.SelectedCells.Count >= 0)
                {
                    int selectedrowindex = dataGridView1.SelectedCells[0].RowIndex;

                    DataGridViewRow selectedRow = dataGridView1.Rows[selectedrowindex];

                    string a = Convert.ToString(selectedRow.Cells["id"].Value);

                    SeTV1 = a;

                    OP_ed();

                }
            }
        }

        private void actualizarT(int id, int tpe)
        {

            RT.Rows.Clear();
            dataGridView1.Refresh();
            dataGridView1.ReadOnly = true;
            dataGridView1.DataSource = RT;


      

           matDB tab = new matDB();

            RT = tab.lista(id, tpe);

           
           

            if (RT.Rows.Count > 0)
            {

                dataGridView1.ReadOnly = true;
                dataGridView1.DataSource = RT;
                dataGridView1.AutoResizeColumns();
                dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            }
            else
            {
                MessageBox.Show("sin materias");
            }

            Act = true;

            if (inicio.VAL == "4")
            {
                agregar.Enabled = true;
            }

          
        }

    }
}
