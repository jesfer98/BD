﻿namespace WindowsFormsApp1
{
    partial class putcalif
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.Lalumn = new System.Windows.Forms.Label();
            this.Lmatri = new System.Windows.Forms.Label();
            this.id = new System.Windows.Forms.Label();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.Lmateria = new System.Windows.Forms.Label();
            this.Lgrupo = new System.Windows.Forms.Label();
            this.lcar = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(532, 164);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "salir";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(23, 161);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 1;
            this.button2.Text = "aceptar";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Lalumn
            // 
            this.Lalumn.AutoSize = true;
            this.Lalumn.Location = new System.Drawing.Point(102, 9);
            this.Lalumn.Name = "Lalumn";
            this.Lalumn.Size = new System.Drawing.Size(54, 17);
            this.Lalumn.TabIndex = 2;
            this.Lalumn.Text = "alumno";
            // 
            // Lmatri
            // 
            this.Lmatri.AutoSize = true;
            this.Lmatri.Location = new System.Drawing.Point(529, 8);
            this.Lmatri.Name = "Lmatri";
            this.Lmatri.Size = new System.Drawing.Size(54, 17);
            this.Lmatri.TabIndex = 3;
            this.Lmatri.Text = "alumno";
            // 
            // id
            // 
            this.id.AutoSize = true;
            this.id.Location = new System.Drawing.Point(352, 167);
            this.id.Name = "id";
            this.id.Size = new System.Drawing.Size(54, 17);
            this.id.TabIndex = 4;
            this.id.Text = "alumno";
            this.id.Visible = false;
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(486, 111);
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(120, 22);
            this.numericUpDown1.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(403, 113);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 17);
            this.label1.TabIndex = 6;
            this.label1.Text = "calificacion";
            // 
            // Lmateria
            // 
            this.Lmateria.AutoSize = true;
            this.Lmateria.Location = new System.Drawing.Point(102, 90);
            this.Lmateria.Name = "Lmateria";
            this.Lmateria.Size = new System.Drawing.Size(54, 17);
            this.Lmateria.TabIndex = 7;
            this.Lmateria.Text = "alumno";
            // 
            // Lgrupo
            // 
            this.Lgrupo.AutoSize = true;
            this.Lgrupo.Location = new System.Drawing.Point(529, 42);
            this.Lgrupo.Name = "Lgrupo";
            this.Lgrupo.Size = new System.Drawing.Size(54, 17);
            this.Lgrupo.TabIndex = 8;
            this.Lgrupo.Text = "alumno";
            // 
            // lcar
            // 
            this.lcar.AutoSize = true;
            this.lcar.Location = new System.Drawing.Point(102, 56);
            this.lcar.Name = "lcar";
            this.lcar.Size = new System.Drawing.Size(54, 17);
            this.lcar.TabIndex = 9;
            this.lcar.Text = "alumno";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(32, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 17);
            this.label2.TabIndex = 10;
            this.label2.Text = "alumno";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(437, 8);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 17);
            this.label3.TabIndex = 11;
            this.label3.Text = "matricula";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(32, 56);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(54, 17);
            this.label4.TabIndex = 12;
            this.label4.Text = "carrera";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(32, 90);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(55, 17);
            this.label5.TabIndex = 13;
            this.label5.Text = "materia";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(470, 42);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(45, 17);
            this.label6.TabIndex = 14;
            this.label6.Text = "grupo";
            // 
            // putcalif
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(626, 207);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lcar);
            this.Controls.Add(this.Lgrupo);
            this.Controls.Add(this.Lmateria);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.numericUpDown1);
            this.Controls.Add(this.id);
            this.Controls.Add(this.Lmatri);
            this.Controls.Add(this.Lalumn);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Name = "putcalif";
            this.Text = "putcalif";
            this.Load += new System.EventHandler(this.putcalif_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label Lalumn;
        private System.Windows.Forms.Label Lmatri;
        private System.Windows.Forms.Label id;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label Lmateria;
        private System.Windows.Forms.Label Lgrupo;
        private System.Windows.Forms.Label lcar;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
    }
}