﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class putcalif : Form
    {
        private static int idE;
        public putcalif()
        {
            InitializeComponent();
        }

        public putcalif(int id)
        {
            idE = id;
            InitializeComponent();
            
        }
        private void putcalif_Load(object sender, EventArgs e)
        {
            modCar();
        }

        private void modCar()
        {
            DataTable RT = new DataTable();
            RT.Rows.Clear();
            TAC cod = new TAC();
            RT = cod.regm(idE);
            int cord;
            if (RT.Rows.Count == 1)
            {

                id.Text = RT.Rows[0][0].ToString();
                Lalumn.Text = RT.Rows[0][1].ToString();
                Lmatri.Text = RT.Rows[0][2].ToString();
                lcar.Text = RT.Rows[0][3].ToString();
                Lmateria.Text = RT.Rows[0][4].ToString();
                Lgrupo.Text = RT.Rows[0][5].ToString();
                if (RT.Rows[0][6].ToString() == "")
                {
                    cord = 0;
                }
                else
                {
                    cord = Int32.Parse(RT.Rows[0][6].ToString());
                }
                numericUpDown1.Value = cord;

                
            }


        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            cambcal();
            this.Close();
        }

        private void cambcal() {
            TAC cal = new TAC();
              int  cord = Int32.Parse(id.Text);
            int call= Int32.Parse(numericUpDown1.Value.ToString());
            cal.modcal(call,cord);

        }
    }
}
