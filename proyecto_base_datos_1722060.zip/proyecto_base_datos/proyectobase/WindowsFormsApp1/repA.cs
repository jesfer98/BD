﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class repA : Form
    {
        DataTable DT = new DataTable();
        private Boolean activo = true;
        private int VAL = 1;

        public repA()
        {
            InitializeComponent();
        }

        private void repA_Load(object sender, EventArgs e)
        {
            // actualizaT(1);
            FilCB2();
            activo = true;
        }

        private void actualizaT(int a)
        {
           
            DT.Rows.Clear();
            dataGridView1.DataSource = null;
            dataGridView1.Refresh();
            dataGridView1.ReadOnly = true;
            dataGridView1.DataSource = DT;





            repp prom = new repp();
            if (a == 1)
                DT = prom.repA(VAL);
            else if (a == 2)
                DT = prom.repC(0);
            else if (a == 3)
                DT = prom.repM(0);

            if (DT.Rows.Count > 0)
            {
                DataView DV = new DataView(DT);



                dataGridView1.ReadOnly = true;
                dataGridView1.DataSource = DV;
                dataGridView1.AutoResizeColumns();
                dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            }
            else
            {
                MessageBox.Show("no hay alumnos inscritos");
            }

           
        }

        private void FilCB2()
        {
            DataTable DT2 = new DataTable();
            DT2.Rows.Clear();
            CB_sem.DisplayMember = "";
            CB_sem.ValueMember = "";

            semDB cox = new semDB();

            DT2 = cox.semCB();

            CB_sem.DataSource = DT2;
            CB_sem.DisplayMember = "descripcion";
            CB_sem.ValueMember = "id";
            CB_sem.DataSource = DT2;
            CB_sem.SelectedIndex = -1;
        }

        private void vista()
        {
            if (activo == false)
            {
                activo = true;
                if (CB_sem.Text != "")
                {
                    
                    string P = CB_sem.Text;

                    if (P != "" && P != "System.Data.DataRowView" && CB_sem.SelectedValue.ToString() != "System.Data.DataRowView")
                    {
                        actualizaT(1);
                        //  MessageBox.Show(CB_GR.SelectedValue.ToString());
                        if (DT.Rows.Count > 0)
                        {
                            DataView RV = new DataView(DT);
                            RV.RowFilter = "semestre ='" + CB_sem.Text + "'";

                            dataGridView1.Refresh();
                            dataGridView1.ReadOnly = true;
                            dataGridView1.DataSource = RV;

                        }
                    }
                }
            }
        }

        private void repA_MouseEnter(object sender, EventArgs e)
        {
            if (activo == false)
            {
                vista();
            }
        }

        private void CB_sem_SelectedIndexChanged(object sender, EventArgs e)
        {
            activo = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            VAL = 1;
            activo = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            VAL = 2;
            activo = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            VAL = 3;
            activo = false;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            VAL = 4;
            activo = false;
        }
    }
}
