﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class repC : Form
    {
        DataTable DT = new DataTable();
        private Boolean activo = true;
        private int VAL = 1;
        public repC()
        {
            InitializeComponent();
        }

        private void repC_Load(object sender, EventArgs e)
        {
            //actualizaT(2);
            FilCB(0);
            VAL = 1;
        }
        private void actualizaT(int a)
        {
           
            DT.Rows.Clear();
            dataGridView1.DataSource = null;
            dataGridView1.Refresh();
            dataGridView1.ReadOnly = true;
            dataGridView1.DataSource = DT;





            repp prom = new repp();
            if (a == 1)
                DT = prom.repA(0);
            else if (a == 2)
                DT = prom.repC(VAL);
            else if (a == 3)
                DT = prom.repM(0);

            if (DT.Rows.Count > 0)
            {
                DataView DV = new DataView(DT);



                dataGridView1.ReadOnly = true;
                dataGridView1.DataSource = DV;
                dataGridView1.AutoResizeColumns();
                dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            }
            else
            {
                MessageBox.Show("no hay alumnos inscritos");
            }


        }

        private void FilCB(int SeT)
        {
            DataTable DT2 = new DataTable();
            DT2.Rows.Clear();
            CB_car.DisplayMember = "";
            CB_car.ValueMember = "";

            CarDB cox = new CarDB();

            DT2 = cox.CBcar_A(SeT);

            CB_car.DataSource = DT2;
            CB_car.DisplayMember = "nombre";
            CB_car.ValueMember = "id";
            CB_car.DataSource = DT2;
            CB_car.SelectedIndex = -1;
        }

        private void CB_car_SelectedIndexChanged(object sender, EventArgs e)
        {
            activo = false;
        }

        private void repC_Activated(object sender, EventArgs e)
        {
          //  vista();
        }

        private void vista() {
            if (activo == false)
            {
                activo = true;
                if (CB_car.Text != "")
                {
                    actualizaT(2);
                    if (DT.Rows.Count > 0)
                    {
                        DataView RV = new DataView(DT);
                        RV.RowFilter = "carrera ='" + CB_car.Text + "'";

                        dataGridView1.Refresh();
                        dataGridView1.ReadOnly = true;
                        dataGridView1.DataSource = RV;

                    }

                }

            }
        }

        private void repC_MouseEnter(object sender, EventArgs e)
        {
            vista();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            VAL = 1;
            activo = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            VAL = 2;
            activo = false;
        }
    }
}
