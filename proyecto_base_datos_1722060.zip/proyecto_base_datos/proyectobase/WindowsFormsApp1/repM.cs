﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class repM : Form
    {
        DataTable DT = new DataTable();
        private Boolean activo = true;
        private int VAL = 1;

        public repM()
        {
            InitializeComponent();
        }

        private void repM_Load(object sender, EventArgs e)
        {
            //actualizaT(3);
            FilCB2();
        }

        private void FilCB2()
        {
            DataTable DT2 = new DataTable();
            DT2.Rows.Clear();
            CB_mat.DisplayMember = "";
            CB_mat.ValueMember = "";

            //semDB cox = new semDB();

            //DT2 = cox.semCB();

            matDB cox = new matDB();
            DT2 = cox.lista(0,0);

            CB_mat.DataSource = DT2;
            CB_mat.DisplayMember = "nombre";
            CB_mat.ValueMember = "id";
            CB_mat.DataSource = DT2;
            CB_mat.SelectedIndex = -1;
        }

        private void actualizaT(int a)
        {
           
            DT.Rows.Clear();
            dataGridView1.DataSource = null;
            dataGridView1.Refresh();
            dataGridView1.ReadOnly = true;
            dataGridView1.DataSource = DT;





            repp prom = new repp();
            if (a == 1)
                DT = prom.repA(0);
            else if (a == 2)
                DT = prom.repC(0);
            else if (a == 3)
                DT = prom.repM(VAL);

            if (DT.Rows.Count > 0)
            {
                DataView DV = new DataView(DT);



                dataGridView1.ReadOnly = true;
                dataGridView1.DataSource = DV;
                dataGridView1.AutoResizeColumns();
                dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            }
            else
            {
                MessageBox.Show("no hay alumnos inscritos");
            }


        }

        private void CB_mat_SelectedIndexChanged(object sender, EventArgs e)
        {
            activo = false;
        }

        private void repM_MouseEnter(object sender, EventArgs e)
        {
            vista();
        }

        private void vista()
        {
            if (activo == false)
            {
                activo = true;
                if (CB_mat.Text != "")
                {
                    actualizaT(3);
                    if (DT.Rows.Count > 0)
                    {
                        DataView RV = new DataView(DT);
                        RV.RowFilter = "materia='" + CB_mat.Text + "'";

                        dataGridView1.Refresh();
                        dataGridView1.ReadOnly = true;
                        dataGridView1.DataSource = RV;

                    }

                }

            }
        }

        private void salir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            VAL = 2;
            activo = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {

            VAL = 1;
            activo = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {

            VAL = 3;
            activo = false;
        }
    }
}
