﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class reportes : Form
    {
     
        public reportes()
        {
            InitializeComponent();
        }

        private void salir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //      actualizaT(1);
            repA RA = new repA();
            RA.ShowDialog();

        }

  

        private void button2_Click(object sender, EventArgs e)
        {
            //     actualizaT(2);

            repC RA = new repC();
            RA.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
      
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            //  actualizaT(3);

            repM RA = new repM();
            RA.ShowDialog();
        }
    }
}
