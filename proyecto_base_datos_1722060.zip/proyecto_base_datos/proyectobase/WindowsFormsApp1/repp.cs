﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;
using System.Data;

namespace WindowsFormsApp1
{
    class repp: ConDB
    {
        DataTable kr = new DataTable();
        public DataTable kar(int id) {
            

            kr=  R_kar(id);
            return kr;
        }

        public DataTable repA(int VAL)
        {

            if (VAL == 1)
            {
                kr = R_repA1();
            }
            else if(VAL == 2)
            { kr = R_repA2(); }
            else if (VAL == 3)
            { kr = R_repA3(); }
            else if (VAL == 4)
            { kr = R_repA4(); }

            return kr;
        }
        public DataTable repC(int VAL)
        {

            if (VAL == 1)
            {
                kr = R_repC1();
            }else if (VAL == 2)
            {
                kr = R_repC2();
            }
            return kr;
        }
        public DataTable repM(int VAL)
        {

            if (VAL == 1)
            {
                kr = R_repM1();
            }
            else if (VAL == 3)
            {
                kr = R_repM2();
            }
            else if (VAL == 2)
            {
                kr = R_repM3();
            }
            return kr;
        }
    }
}
