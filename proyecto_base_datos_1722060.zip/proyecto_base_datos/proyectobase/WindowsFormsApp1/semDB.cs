﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    class semDB: ConDB
    {   DataTable RTS = new DataTable();
        public DataTable DTS = new DataTable();



       

        public DataTable perAct()
        {


            
            RTS = S_perAct();

            return RTS;
        }

        public void CerIns(int id) {
            
            S_CerIns(id);
            
            
        }

        public void FinSem(int id)
        {
            
            S_FinSem(id);


        }

        public void newSem(string desc,int id) {
           S_newSem(desc, id);

          
        }

        public DataTable compr(string desc)
        {
            DataTable RT = new DataTable();

            
            RT =S_compr(desc);

            return RT;
        }

        public void newSem2(string desc, int ced)
        {
          
            S_newSem2(desc, ced);

          

        }

        public DataTable semCB()
        {



            RTS = S_fillCB();

            return RTS;
        }

    }
}
