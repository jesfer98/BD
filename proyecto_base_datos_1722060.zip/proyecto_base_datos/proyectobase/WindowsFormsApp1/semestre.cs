﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class semestre : Form
    {
        private DataTable DT = new DataTable();
        public static string SetValueForText1 = "";
        public static Boolean Act = false;
        string mystring = "";
        string res;
        public semestre()
        {
            InitializeComponent();
        }

        private void semestre_Load(object sender, EventArgs e)
        {

            

           
        }

        private string GetLast( string source, int tail_length)
        {
            if (tail_length >= source.Length)
                return source;
            return source.Substring(source.Length - tail_length);
        }

        private void salir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // mystring = textBox1.Text;

            //if (mystring.Length > 4)
            //    res = GetLast(mystring, 4);
            //else
            //    res = "";

            //MessageBox.Show(res);
        }

        private void crea_Click(object sender, EventArgs e)
        {
            semDB P_E = new semDB();

            DT = P_E.compr(textBox1.Text);
            if (textBox1.Text != "")
            {
                if (DT.Rows.Count < 1)
                {
                    P_E.newSem2(textBox1.Text, Convert.ToInt32(num_ct.Value.ToString()));
                    this.Close();
                }
                else
                {
                    MessageBox.Show("descripcion ya existente");
                }
            }
            else
            {
                MessageBox.Show("introducir descripcion");
            }
        }
    }
}
